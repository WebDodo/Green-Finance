"""
Lichen AM — extraction des cours Yahoo Finance pour tout l'univers MSCI World (all_data.csv).

À lancer UNE fois, depuis le dossier « Lichen AM » :
    pip install yfinance pandas
    python code_py/extraire_prix_yahoo.py

Durée : 5 à 15 minutes. Résultats écrits dans data/externes/ :
    - prix_yahoo_quotidiens.csv : cours de clôture ajustés (dividendes et divisions), un ticker par colonne, en devise locale
    - change_eur.csv            : combien d'unités de devise pour 1 euro (EURUSD=X, etc.)
    - extraction_yahoo_log.csv  : ticker par ticker, nombre de cours récupérés (pour repérer les manquants)
"""
import time
from pathlib import Path

import pandas as pd
import yfinance as yf

RACINE = Path(__file__).resolve().parent.parent
DONNEES = RACINE / "data"
SORTIE = DONNEES / "externes"
SORTIE.mkdir(parents=True, exist_ok=True)

DEBUT, FIN = "2019-12-01", "2026-11-21"   # 5 ans avant la date de sélection (31/12/2024) + toute la période 2025-2026
TAILLE_LOT = 100

univers = pd.read_csv(DONNEES / "all_data.csv")
tickers = sorted(univers["ticker_yahoo"].dropna().unique().tolist())

# Références : ETF MSCI World et ETF MSCI World Climate Paris Aligned
REFERENCES = {
    "URTH": "iShares MSCI World ETF (USD)",
    "IWDA.AS": "iShares Core MSCI World UCITS ETF (EUR)",
    "PABW.DE": "Amundi MSCI World Climate Paris Aligned (EUR)",
    "PABV.DE": "Amundi MSCI World Climate Paris Aligned Select (EUR)",
    "WPAB.L": "iShares MSCI World Paris-Aligned Climate (USD)",
}
tickers += [t for t in REFERENCES if t not in tickers]


def telecharger(liste, essais=3):
    for i in range(essais):
        try:
            p = yf.download(liste, start=DEBUT, end=FIN, auto_adjust=True, progress=False, threads=True)["Close"]
            if isinstance(p, pd.Series):
                p = p.to_frame(liste[0])
            return p
        except Exception as e:  # coupure réseau ou limite Yahoo : on attend puis on réessaie
            print(f"   erreur ({e}), nouvel essai dans 10 s…")
            time.sleep(10)
    return pd.DataFrame()


morceaux = []
for k in range(0, len(tickers), TAILLE_LOT):
    lot = tickers[k:k + TAILLE_LOT]
    print(f"Lot {k // TAILLE_LOT + 1} / {(len(tickers) - 1) // TAILLE_LOT + 1} ({len(lot)} tickers)")
    morceaux.append(telecharger(lot))
    time.sleep(2)
prix = pd.concat(morceaux, axis=1)
prix = prix.loc[:, ~prix.columns.duplicated()].sort_index()
prix.index.name = "Date"
prix.to_csv(SORTIE / "prix_yahoo_quotidiens.csv")

# Taux de change : unités de devise pour 1 euro
# GBp (pence) et ILs (agorot) deviennent GBP et ILS ; la division par 100 se fera à l'analyse
devises = sorted((set(univers["currency"].dropna().str.upper()) - {"EUR"}) | {"USD"})
change = telecharger([f"EUR{d}=X" for d in devises])
change.columns = [c.replace("EUR", "", 1).replace("=X", "") for c in change.columns]
change.index.name = "Date"
change.to_csv(SORTIE / "change_eur.csv")

# Journal : combien de cours par ticker
log = pd.DataFrame({"ticker_yahoo": tickers})
log["nb_cours"] = [int(prix[t].notna().sum()) if t in prix else 0 for t in tickers]
log["premier_cours"] = [prix[t].first_valid_index() if t in prix else None for t in tickers]
log.to_csv(SORTIE / "extraction_yahoo_log.csv", index=False)

manquants = log[log["nb_cours"] == 0]["ticker_yahoo"].tolist()
print(f"\nTerminé : {prix.shape[1]} séries, du {prix.index.min().date()} au {prix.index.max().date()}.")
print(f"Tickers sans aucun cours : {len(manquants)} {manquants[:20]}")
print(f"Fichiers écrits dans {SORTIE}")
