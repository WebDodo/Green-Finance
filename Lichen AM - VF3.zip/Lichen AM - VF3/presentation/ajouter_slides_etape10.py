# Ajoute les slides de l'étape 10 (poches, pondération, portefeuille, résultats, conformité, performance, fiche)
# à la présentation, dans la charte Lichen. Les chiffres sont lus dans resultats/ (produits par Lichen_AM_V17.ipynb).
# Lancer depuis le dossier presentation/ :  python ajouter_slides_etape10.py

import copy
import pandas as pd
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_THEME_COLOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Inches, Pt

RES = '../resultats/'
FIG = RES + 'figures/'
pres = Presentation('Lichen_AM_Presentation.pptx')
CONTENU = [l for l in pres.slide_layouts if l.name == 'CONTENU'][0]

conf = pd.read_csv(RES + 'conformite.csv')
poches = pd.read_csv(RES + 'poches_lichen.csv', index_col=0)
extra = pd.read_csv(RES + 'resultats_extra_financiers.csv', index_col=0)
perf = pd.read_csv(RES + 'performance.csv', header=[0, 1], index_col=0)
pf = pd.read_excel(RES + 'Lichen_Portefeuille.xlsx', sheet_name='Portefeuille')

fr = lambda x, d=1: f"{x:,.{d}f}".replace(',', ' ').replace('.', ',')     # 1 234,5
pc = lambda x, d=1, signe=False: (f"{x * 100:+.{d}f}" if signe else f"{x * 100:.{d}f}").replace('.', ',').replace('-', '−') + ' %'


# ---------------------------------------------------------------- petites briques de mise en page
def nouvelle_slide(titre):
    s = pres.slides.add_slide(CONTENU)
    zones = sorted(s.placeholders, key=lambda ph: ph.top)
    zones[0].text_frame.text = titre                                   # la zone de titre est la plus haute
    for ph in zones[1:]:
        if ph.placeholder_format.type != 13:                           # on garde le numéro de slide (type 13)
            ph._element.getparent().remove(ph._element)
    return s


def boite(s, x, y, w, h, couleur=MSO_THEME_COLOR.BACKGROUND_2, forme=MSO_SHAPE.ROUNDED_RECTANGLE):
    b = s.shapes.add_shape(forme, Inches(x), Inches(y), Inches(w), Inches(h))
    b.fill.solid()
    b.fill.fore_color.theme_color = couleur
    b.line.fill.background()
    b.shadow.inherit = False
    if forme == MSO_SHAPE.ROUNDED_RECTANGLE:
        b.adjustments[0] = 0.08
    return b


def texte(s, x, y, w, h, lignes, taille=14, couleur=MSO_THEME_COLOR.TEXT_2, gras=False, police=None,
          align=PP_ALIGN.LEFT, ancre=MSO_ANCHOR.TOP):
    """lignes : une chaîne, ou une liste de paragraphes ; un paragraphe = chaîne ou liste de (texte, options)."""
    t = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h)).text_frame
    t.word_wrap = True
    t.vertical_anchor = ancre
    t.margin_left = t.margin_right = t.margin_top = t.margin_bottom = 0
    for i, ligne in enumerate([lignes] if isinstance(lignes, str) else lignes):
        p = t.paragraphs[0] if i == 0 else t.add_paragraph()
        p.alignment = align
        p.space_after = Pt(4)
        for morceau in ([(ligne, {})] if isinstance(ligne, str) else ligne):
            contenu, opt = morceau if isinstance(morceau, tuple) else (morceau, {})
            r = p.add_run()
            r.text = contenu
            r.font.size = Pt(opt.get('taille', taille))
            r.font.bold = opt.get('gras', gras)
            r.font.color.theme_color = opt.get('couleur', couleur)
            if opt.get('police', police):
                r.font.name = opt.get('police', police)
    return t


def chiffre(s, x, y, w, valeur, legende, couleur_pastille=MSO_THEME_COLOR.ACCENT_1, h=1.12):
    """Carte « grand chiffre » comme sur la slide d'annexe : pastille, chiffre en Cambria, légende."""
    boite(s, x, y, w, h)
    boite(s, x + 0.2, y + h / 2 - 0.2, 0.4, 0.4, couleur_pastille, MSO_SHAPE.OVAL)
    texte(s, x + 0.75, y + 0.08, 1.75, h - 0.16, valeur, 26, MSO_THEME_COLOR.TEXT_1, True, 'Cambria', ancre=MSO_ANCHOR.MIDDLE)
    texte(s, x + 2.5, y + 0.08, w - 2.65, h - 0.16, legende, 12, ancre=MSO_ANCHOR.MIDDLE)


def encadre(s, x, y, w, h, titre, corps):
    boite(s, x, y, w, h, MSO_THEME_COLOR.TEXT_1)
    texte(s, x + 0.3, y + 0.12, w - 0.6, h - 0.24,
          [[(titre, {'gras': True, 'couleur': MSO_THEME_COLOR.ACCENT_2})], [(corps, {'couleur': MSO_THEME_COLOR.BACKGROUND_1})]],
          13, ancre=MSO_ANCHOR.MIDDLE)


def image(s, nom, x, y, w=None, h=None):
    s.shapes.add_picture(FIG + nom, Inches(x), Inches(y), Inches(w) if w else None, Inches(h) if h else None)


def source(s, txt, y=6.85):
    texte(s, 0.5, y, 11.6, 0.25, txt, 9)


def notes(s, txt):
    # le masque des notes du fichier n'a pas de zone de texte : on copie celle des notes d'une slide existante
    ns = s.notes_slide
    if ns.notes_text_frame is None:
        modele = [sh for sh in pres.slides[0].notes_slide.placeholders if sh.placeholder_format.type == 2][0]
        ns.shapes._spTree.append(copy.deepcopy(modele._element))
    ns.notes_text_frame.text = txt


nouvelles = []
P = poches['Photosynthèse'] if 'Photosynthèse' in poches else poches.iloc[:, 1]
N = poches['Noyau']
part_verte = P['Poids']

# ---------------------------------------------------------------- 1. Les deux poches
s = nouvelle_slide('Deux poches, une symbiose')
image(s, 'G14_carte_poches.png', 0.5, 1.4, h=5.3)
chiffre(s, 8.0, 1.45, 4.83, pc(part_verte, 0),
        [[('Photosynthèse · l\'algue', {'gras': True, 'couleur': MSO_THEME_COLOR.TEXT_1})],
         f"{int(P['Lignes'])} lignes : les meilleures en vert, CA vert ≥ 10 %, 5 au plus par secteur"], h=1.55)
chiffre(s, 8.0, 3.15, 4.83, pc(N['Poids'], 0),
        [[('Noyau · le champignon', {'gras': True, 'couleur': MSO_THEME_COLOR.TEXT_1})],
         f"{int(N['Lignes'])} lignes : les meilleures en financier, réparties comme le MSCI World"],
        MSO_THEME_COLOR.TEXT_1, h=1.55)
encadre(s, 8.0, 4.9, 4.83, 1.8, 'Toutes les lignes sont Article 9',
        "Les deux poches viennent des 339 entreprises durables et solides. Avant de choisir, la revue "
        "qualitative a écarté l'or, le saumon d'élevage, la fast fashion et la réservation de vols.")
source(s, f"Photosynthèse : CA vert moyen {fr(P['CA vert (%)'])} %, {fr(P['Température (°C)'], 2)} °C · "
          f"Noyau : score financier moyen {fr(N['Score financier moyen'], 0)}/100, volatilité {pc(N['Volatilité 5 ans'], 0)}. "
          "Taille des points = poids dans le fonds.")
notes(s, "Message : le fonds a l'architecture d'un lichen. La poche Photosynthèse (l'algue) finance les solutions de la "
         "transition : les meilleures entreprises en score vert, parmi celles qui réalisent au moins 10 % de leur chiffre "
         "d'affaires dans des activités vertes. La poche Noyau (le champignon) apporte la structure et la performance : les "
         "meilleures en score financier, réparties entre secteurs comme le MSCI World, banques et assureurs compris. "
         "Les deux notes étant presque indépendantes (corrélation 0,07), deux poches permettent de prendre le meilleur des deux. "
         "Revue qualitative : Mowi (saumon d'élevage), Agnico Eagle et Wheaton (or), Inditex (fast fashion) et Amadeus "
         "(réservation de vols) sont écartées : leurs notes sont bonnes, mais leur activité contredit notre objectif.")
nouvelles.append(s)

# ---------------------------------------------------------------- 2. La pondération
s = nouvelle_slide('La pondération : au plus près du MSCI World')
image(s, 'G10_choix_poche_verte.png', 0.5, 1.45, w=7.2)
texte(s, 0.5, 5.0, 7.2, 1.7, [
    [('Méthode du cours (Approche Quantitative) : ', {'gras': True, 'couleur': MSO_THEME_COLOR.TEXT_1}),
     'poids de départ égaux, somme = 100 %, chaque ligne entre 0,5 % et 5 %, et on minimise la tracking error '
     'face au MSCI World.'],
    [('Les contraintes : ', {'gras': True, 'couleur': MSO_THEME_COLOR.TEXT_1}),
     'température < 2 °C · carbone ≤ 50 % du MSCI World · CA vert ≥ 1,5 × MSCI World · secteurs à fort impact ≥ MSCI World · '
     'chaque secteur à ± 5 points, chaque région à ± 10 points.']], 12)
chiffre(s, 8.0, 1.45, 4.83, pc(part_verte, 0), 'du fonds en Photosynthèse : la taille qui minimise la tracking error')
chiffre(s, 8.0, 2.77, 4.83, '4,6 %', 'de tracking error ex ante : le fonds reste proche du MSCI World')
chiffre(s, 8.0, 4.09, 4.83, f"{len(pf)}", 'lignes, de 0,5 % à 5 % chacune')
encadre(s, 8.0, 5.41, 4.83, 1.3, 'Pourquoi ' + pc(part_verte, 0) + ' ?',
        "On choisit la taille de la poche comme les poids : en minimisant l'écart au marché. "
        "Jusqu'à 65 %, le vert ne coûte presque rien en risque.")
notes(s, "Message : les poids sont calculés par optimisation, avec la méthode du cours : poids initiaux égaux (1/N), "
         "somme des poids égale à 1, bornes par ligne (0,5 % à 5 %, ce qui respecte la règle 5/10/40 des OPCVM), et on "
         "minimise la tracking error ex ante face au MSCI World, calculée sur les rendements hebdomadaires en euros 2020-2024. "
         "Un petit terme de rappel vers les scores évite que l'optimiseur mette la moitié des lignes au plancher. "
         "Taille de la poche verte : nous avons testé de 20 % à 70 %. À 20 %, le CA vert est insuffisant ; à 70 %, "
         "l'équilibre sectoriel casse. Entre les deux, la tracking error bouge à peine (4,6 à 5,0 %) : nous retenons "
         "celle qui la minimise, 55 %. Le vert ne coûte presque rien en risque. Pourquoi pas 1,5 °C ? Nous l'avons testé : c'est faisable, mais la tracking error monte à 5,5 %, le CA vert et la part notée AA-AAA baissent, et 5 lignes se retrouvent bloquées au plafond de 5 %. Notre fonds est à 1,69 °C, bien en dessous de 2 °C comme le demande l'Accord de Paris, et son carbone est déjà divisé par plus de deux.")
nouvelles.append(s)

# ---------------------------------------------------------------- 3. Le portefeuille
s = nouvelle_slide('Le portefeuille : un fonds équilibré')
image(s, 'G11_secteurs_regions.png', 0.5, 1.45, w=8.1)
top = pf.nlargest(10, 'Poids')
boite(s, 8.95, 1.45, 3.88, 5.25)
texte(s, 9.15, 1.55, 3.5, 0.35, 'Les 10 premières lignes', 13, MSO_THEME_COLOR.TEXT_1, True)
nom_court = lambda n: (n.replace(' Inc', '').replace(' Corp', '').replace(' Ltd', '').replace(' PLC', '').replace(' SE', '')
                       .replace(' SA', '').replace(' AG', '').replace(' NV', '').strip())[:24]
texte(s, 9.15, 2.0, 2.45, 4.6, [f"{i}. {nom_court(n)}" for i, n in enumerate(top['Entreprise'], 1)], 11)
texte(s, 11.55, 2.0, 1.1, 4.6, [[(pc(w), {'gras': True, 'couleur': MSO_THEME_COLOR.ACCENT_1 if p == 'Photosynthèse' else MSO_THEME_COLOR.TEXT_1})]
                                 for w, p in zip(top['Poids'], top['Poche'])], 11, align=PP_ALIGN.RIGHT)
texte(s, 9.15, 6.2, 3.5, 0.4, [[('■ Photosynthèse  ', {'couleur': MSO_THEME_COLOR.ACCENT_1, 'gras': True}),
                                ('■ Noyau', {'couleur': MSO_THEME_COLOR.TEXT_1, 'gras': True})]], 10)
texte(s, 0.5, 5.0, 8.1, 1.6, [
    [('Plus de solutions : ', {'gras': True, 'couleur': MSO_THEME_COLOR.TEXT_1}),
     'industrie, services aux collectivités, matériaux et immobilier surpondérés (+5 points chacun).'],
    [('Moins de ce qui pollue ou se mesure mal : ', {'gras': True, 'couleur': MSO_THEME_COLOR.TEXT_1}),
     'pas d\'énergie, finance et santé à −5 points.'],
    [('Toujours un fonds monde : ', {'gras': True, 'couleur': MSO_THEME_COLOR.TEXT_1}),
     '66 % en Amérique du Nord, 26 % en Europe, tous les écarts dans les limites.']], 12)
notes(s, "Message : le fonds reste équilibré. Chaque secteur est à 5 points au plus du MSCI World et chaque région à 10 points "
         "au plus. Les écarts racontent la thèse : plus d'industrie (ingénierie de l'eau, efficacité énergétique), de services "
         "aux collectivités (réseaux, renouvelables), de matériaux et d'immobilier bas carbone ; pas d'énergie fossile ; "
         "moins de finance et de santé. Les plus grosses lignes sont Microsoft et Alphabet (5 %, Noyau) et des leaders "
         "verts comme Autodesk, NVIDIA, AECOM ou Jacobs (Photosynthèse).")
nouvelles.append(s)

# ---------------------------------------------------------------- 4. Résultats extra-financiers
s = nouvelle_slide('Résultats extra-financiers : le fonds face au marché')
image(s, 'G12_resultats_extra_financiers.png', 0.5, 1.4, w=12.33)
lig = lambda debut: extra[extra.index.str.startswith(debut)].iloc[0]
emp, itr, aa, ctr = lig('Empreinte'), lig('Température'), lig('Part notée'), lig('Part en controverse')
y = 5.3
chiffre(s, 0.5, y, 2.95, pc(emp['Écart'], 0, True).replace(' %', ' %'), "d'empreinte carbone (scopes 1+2+3) : Paris-Aligned", h=1.35)
chiffre(s, 3.63, y, 2.95, fr(itr['Fonds'], 2) + ' °C', f"de température implicite, contre {fr(itr['MSCI World'], 2)} °C", h=1.35)
chiffre(s, 6.76, y, 2.95, fr(aa['Fonds'], 0) + ' %', f"notés AA ou AAA par MSCI, contre {fr(aa['MSCI World'], 0)} %", h=1.35)
chiffre(s, 9.89, y, 2.94, fr(ctr['Fonds'], 0) + ' %', f"en controverse grave, contre {fr(ctr['MSCI World'], 0)} % du marché", h=1.35)
notes(s, "Message : le fonds tient ses promesses extra-financières. Empreinte carbone (scopes 1+2+3, par million investi) "
         "inférieure de plus de moitié à celle du MSCI World : c'est l'exigence Paris-Aligned de l'article 9.3. Température "
         "implicite sous 1,7 °C, contre 2,4 °C pour le marché : compatible avec l'Accord de Paris (bien en dessous de 2 °C). "
         "Chiffre d'affaires vert presque deux fois supérieur au marché. Trois quarts du fonds noté AA ou AAA, et aucune "
         "entreprise en controverse grave, contre un tiers du marché.")
nouvelles.append(s)

# ---------------------------------------------------------------- 5. Conformité
s = nouvelle_slide(f"Conformité : {int(conf['Respectée'].sum())} règles sur {len(conf)} respectées")
lignes, colonnes = len(conf) + 1, 5
tab = s.shapes.add_table(lignes, colonnes, Inches(0.5), Inches(1.4), Inches(12.33), Inches(5.3)).table
for j, (titre, larg) in enumerate(zip(['Cadre', 'Règle', 'Fonds', 'Limite', ''], [2.4, 5.6, 2.2, 1.6, 0.53])):
    tab.columns[j].width = Inches(larg)
for i in range(lignes):
    vals = ['Cadre', 'Règle', 'Fonds', 'Limite', ''] if i == 0 else list(conf.iloc[i - 1, :4]) + ['✓' if conf.iloc[i - 1, 4] else '✗']
    vals[2] = str(vals[2]).replace('.', ',').replace('%', ' %').replace('  %', ' %')
    for j, v in enumerate(vals):
        c = tab.cell(i, j)
        c.fill.solid()
        c.fill.fore_color.theme_color = MSO_THEME_COLOR.TEXT_1 if i == 0 else (MSO_THEME_COLOR.BACKGROUND_2 if i % 2 else MSO_THEME_COLOR.BACKGROUND_1)
        c.margin_top = c.margin_bottom = Inches(0.03)
        p = c.text_frame.paragraphs[0]
        r = p.add_run()
        r.text = str(v)
        r.font.size = Pt(11)
        r.font.bold = i == 0 or j in (2, 4)
        r.font.color.theme_color = MSO_THEME_COLOR.BACKGROUND_1 if i == 0 else (MSO_THEME_COLOR.ACCENT_1 if j == 4 else MSO_THEME_COLOR.TEXT_1)
        if j == 4:
            p.alignment = PP_ALIGN.CENTER
notes(s, "Message : toutes les règles sont vérifiées sur les poids finaux, recalculées par le code. Article 9 : 100 % des "
         "lignes sont des investissements durables. OPCVM : aucune ligne au-dessus de 5 %, donc la règle 5/10/40 est "
         "respectée d'office. Paris-Aligned : exclusions appliquées, carbone divisé par plus de deux, exposition aux secteurs "
         "à fort impact climatique au moins égale à celle du marché (on finance la transition, on ne fuit pas l'industrie). "
         "Accord de Paris : température du fonds sous 2 °C. Équilibre : secteurs et régions dans les limites.")
nouvelles.append(s)

# ---------------------------------------------------------------- 6. Performance
p20, p25 = perf['2020-2024'], perf['2025-2026']
s = nouvelle_slide('Performance passée : défensif, moins volatil')
image(s, 'G13_performance.png', 0.5, 1.35, w=12.33)
f20, m20 = p20['Lichen Symbiose Climat'], p20['MSCI World (IWDA)']
f25, m25 = p25['Lichen Symbiose Climat'], p25['MSCI World (IWDA)']
chiffre(s, 0.5, 5.95, 4.0, pc(f20['Performance annualisée']) , f"par an en 2020-2024, contre {pc(m20['Performance annualisée'])} (période de sélection)", h=0.85)
chiffre(s, 4.67, 5.95, 4.0, pc(f25['Performance annualisée']), f"par an depuis 2025, contre {pc(m25['Performance annualisée'])} (vrai test)", h=0.85)
chiffre(s, 8.84, 5.95, 3.99, pc(f25['Volatilité']), f"de volatilité depuis 2025, contre {pc(m25['Volatilité'])}", h=0.85)
source(s, "Performances simulées, en euros, nettes de 0,75 % de frais de gestion par an, poids rééquilibrés chaque mois. "
          "Les performances passées ne préjugent pas des performances futures. Sources : Yahoo Finance, ETF IWDA, PABV, PABW.", 6.88)
notes(s, "Message à dire honnêtement : les titres ont été choisis avec des données arrêtées au 31/12/2024, qui incluent la "
         "performance 2020-2024. Cette période est donc flatteuse par construction. Le vrai test est 2025-2026, que nos "
         "données ne connaissaient pas : le fonds fait moins bien que le MSCI World, porté par l'IA, mais il est moins "
         "volatil et baisse moins (perte maximale plus faible). Il reste proche de l'ETF Paris-Aligned PABW (+12 %). Biais assumés : "
         "univers fixé au 31/12/2024 (biais du survivant), coûts de transaction non comptés.")
nouvelles.append(s)

# ---------------------------------------------------------------- 7. Fiche du fonds et mentions
s = nouvelle_slide('Lichen Symbiose Climat en bref')
fiche = [('Forme', 'FCP de droit français, OPCVM (UCITS), actions monde'),
         ('Classification', 'SFDR Article 9 (9.3, réduction des émissions)'),
         ('Indice de référence', 'MSCI World Climate Paris Aligned'),
         ('Univers', 'MSCI World : 1 247 entreprises → 344 durables et solides'),
         ('Portefeuille', f"{len(pf)} lignes, deux poches : Photosynthèse {pc(part_verte, 0)}, Noyau {pc(N['Poids'], 0)}"),
         ('Frais de gestion', '0,75 % par an'),
         ('Indicateur de risque (SRI)', '4 sur 7'),
         ('Horizon conseillé', '5 ans · liquidité quotidienne')]
tab = s.shapes.add_table(len(fiche), 2, Inches(0.5), Inches(1.45), Inches(7.4), Inches(4.4)).table
tab.columns[0].width, tab.columns[1].width = Inches(2.5), Inches(4.9)
for i, (k, v) in enumerate(fiche):
    for j, val in enumerate((k, v)):
        c = tab.cell(i, j)
        c.fill.solid()
        c.fill.fore_color.theme_color = MSO_THEME_COLOR.BACKGROUND_2 if i % 2 == 0 else MSO_THEME_COLOR.BACKGROUND_1
        r = c.text_frame.paragraphs[0].add_run()
        r.text = val
        r.font.size = Pt(13)
        r.font.bold = j == 0
        r.font.color.theme_color = MSO_THEME_COLOR.TEXT_1
chiffre(s, 8.3, 1.45, 4.53, pc(emp['Écart'], 0, True), "d'empreinte carbone face au MSCI World")
chiffre(s, 8.3, 2.77, 4.53, fr(itr['Fonds'], 2) + ' °C', 'de température implicite')
chiffre(s, 8.3, 4.09, 4.53, '100 %', "d'investissements durables")
encadre(s, 0.5, 6.0, 12.33, 0.85, 'Document à caractère promotionnel',
        "Société de gestion et fonds fictifs (projet universitaire). Risque de perte en capital. Les performances passées ne "
        "préjugent pas des performances futures. Avant d'investir, consultez le DIC et le prospectus.")
notes(s, "Synthèse : un fonds Article 9 Paris-Aligned, en deux poches, qui divise son empreinte carbone par plus de deux, "
         "reste sous 1,7 °C, et reste proche du marché (tracking error de 4,6 %). Mentions AMF : document promotionnel, "
         "risque de perte en capital, performances passées et simulées.")
nouvelles.append(s)

# ---------------------------------------------------------------- on place les nouvelles slides avant l'annexe
liste = pres.slides._sldIdLst
ids = list(liste)
nouveaux = ids[-len(nouvelles):]
titre_de = lambda s: min(s.placeholders, key=lambda ph: ph.top).text_frame.text if len(s.placeholders) else ''
annexes = [i for i, s in zip(ids, pres.slides) if titre_de(s).startswith('Annexe')]
for el in nouveaux:
    liste.remove(el)
position = ids.index(annexes[0]) if annexes else len(liste)
for k, el in enumerate(nouveaux):
    liste.insert(position + k, el)

pres.save('Lichen_AM_Presentation_V2.pptx')
print(f"{len(nouvelles)} slides ajoutées · Lichen_AM_Presentation_V2.pptx ({len(pres.slides)} slides)")
