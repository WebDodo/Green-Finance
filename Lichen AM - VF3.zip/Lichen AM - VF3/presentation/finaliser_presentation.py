"""Finalise la présentation Lichen AM : V2 (Maxime) -> V3 (rendu).

- ajoute une slide « Notre objectif durable » en 2e position ;
- supprime le doublon de la vue d'ensemble des filtres (ancienne slide 9) ;
- passe les zooms des 6 filtres (anciennes slides 3 à 8) en annexe ;
- corrige les slides 15 et 17 (texte écrasé, chevauchements) ;
- harmonise les titres et ajoute le numéro de page sur les slides 12 à 18 ;
- corrige la typographie du tableau de conformité ;
- met à jour les notes de l'orateur liées à la nouvelle structure.

Usage : python finaliser_presentation.py entree.pptx sortie.pptx
"""
import copy
import sys

from pptx import Presentation
from pptx.util import Pt

SRC, DST = sys.argv[1], sys.argv[2]
EMU = 12700  # 1 pt
NBSP = " "

p = Presentation(SRC)
S = list(p.slides)  # index 0 = slide 1 de la V2
ns = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main",
      "p": "http://schemas.openxmlformats.org/presentationml/2006/main"}


def shape(slide, name):
    for sh in slide.shapes:
        if sh.name == name:
            return sh
    raise KeyError(name)


def title_of(slide):
    for sh in slide.shapes:
        if sh.is_placeholder and sh.placeholder_format.type == 1:
            return sh
    raise KeyError("titre")


def geo(sh, x, y, w, h):
    sh.left, sh.top, sh.width, sh.height = (int(v * EMU) for v in (x, y, w, h))


def set_text(sh, text):
    """Remplace le texte du premier run en gardant sa mise en forme."""
    paras = sh.text_frame.paragraphs
    runs = paras[0].runs
    runs[0].text = text
    for r in runs[1:]:
        r._r.getparent().remove(r._r)
    for para in paras[1:]:
        para._p.getparent().remove(para._p)


def nbsp(sh):
    for para in sh.text_frame.paragraphs:
        for r in para.runs:
            r.text = r.text.replace(" %", NBSP + "%").replace(" °C", NBSP + "°C")


def renumber(slide):
    for i, el in enumerate(slide._element.iter("{%s}cNvPr" % ns["p"]), start=2):
        el.set("id", str(i))


def drop_note_lines(slide, starts):
    tf = slide.notes_slide.notes_text_frame
    for para in list(tf.paragraphs):
        if any(para.text.strip().startswith(s) for s in starts):
            para._p.getparent().remove(para._p)


def replace_note(slide, old, new):
    tf = slide.notes_slide.notes_text_frame
    for para in tf.paragraphs:
        if old in para.text:
            full = para.text.replace(old, new)
            para.runs[0].text = full
            for r in para.runs[1:]:
                r._r.getparent().remove(r._r)
            return
    raise ValueError(old)


title_ref = shape(S[1], "Text 0")                      # titre « maison » (34 pt, gras)
slidenum_ref = shape(S[1], "Slide Number Placeholder 0")

# ---------------------------------------------------------------- 1. titres et n° de page (slides 12 à 18)
for sl in S[11:18]:
    old = title_of(sl)
    text = old.text_frame.text
    new = copy.deepcopy(title_ref._element)
    old._element.addprevious(new)
    old._element.getparent().remove(old._element)
    set_text(title_of(sl), text)
    sl.shapes._spTree.append(copy.deepcopy(slidenum_ref._element))
    renumber(sl)

# ---------------------------------------------------------------- 2. slide 15 : résultats extra-financiers
s15 = S[14]
pic = shape(s15, "Picture 2")
ratio = pic.width / pic.height
h = 272
w = h * ratio
geo(pic, (960 - w) / 2, 100.8, w, h)
cards = [("Rounded Rectangle 3", "Oval 4", "TextBox 5", "TextBox 6"),
         ("Rounded Rectangle 7", "Oval 8", "TextBox 9", "TextBox 10"),
         ("Rounded Rectangle 11", "Oval 12", "TextBox 13", "TextBox 14"),
         ("Rounded Rectangle 15", "Oval 16", "TextBox 17", "TextBox 18")]
x0, cw, gap, y0, ch = 36, 212.4, 13.4, 386, 96
for i, (box, oval, num, lab) in enumerate(cards):
    x = x0 + i * (cw + gap)
    geo(shape(s15, box), x, y0, cw, ch)
    geo(shape(s15, oval), x + 16, y0 + 16, 20, 20)
    geo(shape(s15, num), x + 46, y0 + 6, cw - 58, 40)
    geo(shape(s15, lab), x + 16, y0 + 48, cw - 32, 42)
    tf = shape(s15, lab).text_frame
    tf.word_wrap = True
    for para in tf.paragraphs:
        for r in para.runs:
            r.font.size = Pt(11)
    tf._txBody.bodyPr.set("anchor", "t")
    shape(s15, num).text_frame._txBody.bodyPr.set("anchor", "ctr")
    nbsp(shape(s15, lab))
set_text(shape(s15, "TextBox 6"), "d'empreinte carbone (scopes 1+2+3) face au MSCI World : Paris-Aligned")
nbsp(shape(s15, "TextBox 6"))

# ---------------------------------------------------------------- 3. slide 17 : performance
s17 = S[16]
pic = shape(s17, "Picture 2")
ratio = pic.width / pic.height
h = 322
w = h * ratio
geo(pic, (960 - w) / 2, 97.2, w, h)
cards = [("Rounded Rectangle 3", "Oval 4", "TextBox 5", "TextBox 6"),
         ("Rounded Rectangle 7", "Oval 8", "TextBox 9", "TextBox 10"),
         ("Rounded Rectangle 11", "Oval 12", "TextBox 13", "TextBox 14")]
x0, cw, gap, y0, ch = 36, 288, 12, 424, 58
for i, (box, oval, num, lab) in enumerate(cards):
    x = x0 + i * (cw + gap)
    geo(shape(s17, box), x, y0, cw, ch)
    geo(shape(s17, oval), x + 14, y0 + 19, 20, 20)
    geo(shape(s17, num), x + 42, y0 + 4, 100, ch - 8)
    geo(shape(s17, lab), x + 146, y0 + 4, cw - 156, ch - 8)
    for para in shape(s17, lab).text_frame.paragraphs:
        for r in para.runs:
            r.font.size = Pt(11)
    nbsp(shape(s17, lab))
foot = shape(s17, "TextBox 15")
geo(foot, 36, 486, 887.8, 14)
set_text(foot, "Performances simulées, en euros, nettes de 0,75 % de frais de gestion par an, rééquilibrage mensuel. "
               "Les performances passées ne préjugent pas des performances futures. Sources : Yahoo Finance, ETF IWDA, PABV, PABW.")
for r in foot.text_frame.paragraphs[0].runs:
    r.font.size = Pt(8.5)

# ---------------------------------------------------------------- 4. slide 16 : typographie du tableau
for sh in S[15].shapes:
    if sh.has_table:
        for row in sh.table.rows:
            for cell in row.cells:
                for para in cell.text_frame.paragraphs:
                    for r in para.runs:
                        t = r.text.replace("13.9", "13,9")
                        if t.startswith("-"):
                            t = "−" + t[1:]
                        r.text = t

# ---------------------------------------------------------------- 5. annexe : zooms des filtres (slides 3 à 8)
for k, sl in enumerate(S[2:8], start=1):
    set_text(title_of(sl), f"Annexe · Filtre {k} sur 6")
    drop_note_lines(sl, ["(Clic suivant"])

# notes de la vue d'ensemble des filtres (slide 2) : la slide 9 disparaît
replace_note(S[1], "Les clics suivants zooment sur chaque filtre (transition Morphose).",
             "Le détail de chaque filtre est en annexe. Sélectivité : 59,5 % de l'indice exclu, "
             "au-delà des 30 % demandés par le label ISR.")
tf = S[1].notes_slide.notes_text_frame
tf.add_paragraph().text = ""
tf.add_paragraph().text = ("Transition : en parallèle, sur tout le MSCI World, nous vérifions la solidité "
                           "financière des entreprises.")

# ---------------------------------------------------------------- 6. nouvelle slide « Notre objectif durable »
ref = S[18]  # annexe corrélations : cartes chiffrées + encadré sombre
layout = S[1].slide_layout
obj = p.slides.add_slide(layout)
tree = obj.shapes._spTree
for ph in list(obj.placeholders):
    ph._element.getparent().remove(ph._element)
tree.append(copy.deepcopy(title_ref._element))
set_text(title_of(obj), "Notre objectif durable : le climat")
tree.append(copy.deepcopy(slidenum_ref._element))


def clone(name):
    el = copy.deepcopy(shape(ref, name)._element)
    tree.append(el)
    return obj.shapes[-1]


# colonne gauche : la promesse
stmt = clone("Texte 1")
geo(stmt, 36, 104.4, 440, 118)
set_text(stmt, "Investir dans les entreprises qui réduisent les émissions de l'économie "
               "ou en fournissent les solutions, sans renoncer à la performance.")
r = stmt.text_frame.paragraphs[0].runs[0]
r.font.size, r.font.name, r.font.italic = Pt(20), "Cambria", True
stmt.text_frame._txBody.bodyPr.set("anchor", "t")

rules = clone("Texte 1")
geo(rules, 36, 232, 440, 140)
rules.text_frame._txBody.bodyPr.set("anchor", "t")
lines = [("SFDR Article 9.3 : ", "objectif de réduction des émissions de carbone."),
         ("Indice de référence : ", "MSCI World Climate Paris Aligned."),
         ("Nom « Climat » : ", "exclusions Paris-Aligned appliquées (orientations ESMA)."),
         ("Accord de Paris : ", "rester bien en dessous de 2 °C.")]
tf = rules.text_frame
base_p = tf.paragraphs[0]._p
for i, (lab, txt) in enumerate(lines):
    para = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
    if i:
        para._p.insert(0, copy.deepcopy(base_p.find("{%s}pPr" % ns["a"])))
    para.space_after = Pt(6)
    if i == 0:
        para.runs[0].text = lab
        r1 = para.runs[0]
    else:
        r1 = para.add_run()
        r1.text = lab
        r1._r.insert(0, copy.deepcopy(tf.paragraphs[0].runs[0]._r.find("{%s}rPr" % ns["a"])))
    r1.font.bold = True
    r1.font.size = Pt(13)
    r2 = para.add_run()
    r2._r.insert(0, copy.deepcopy(tf.paragraphs[0].runs[0]._r.find("{%s}rPr" % ns["a"])))
    r2.text = txt.replace(" °C", NBSP + "°C")
    r2.font.bold = False
    r2.font.size = Pt(13)

box = clone("Encadré réponse")
geo(box, 36, 389.5, 440, 80.6)
boxt = clone("Texte réponse")
geo(boxt, 54, 395, 404, 70)
ps = boxt.text_frame.paragraphs
ps[0].runs[0].text = "La double durabilité"
ps[1].runs[0].text = ("Chaque ligne est un investissement durable (bonne gouvernance, ne pas nuire, "
                      "contribution) et une entreprise solide financièrement.")
for para in ps:
    for rr in para.runs:
        rr.font.size = Pt(13)

# colonne droite : 4 engagements chiffrés
engagements = [("< 2" + NBSP + "°C", "de température implicite (Accord de Paris) : le fonds est à 1,69" + NBSP + "°C"),
               ("−50" + NBSP + "%", "d'empreinte et d'intensité carbone face au MSCI World (Paris-Aligned)"),
               ("1,5 ×", "le chiffre d'affaires vert du MSCI World : financer les solutions"),
               ("100" + NBSP + "%", "d'investissements durables au sens de l'Article 9")]
for i, (big, small) in enumerate(engagements):
    y = 104.4 + i * 95.05
    geo(clone("Carte 1"), 504, y, 419.8, 80.6)
    geo(clone("Pastille 1"), 520, y + 25.3, 30, 30)
    num = clone("Chiffre 1")
    geo(num, 564, y + 5.8, 120, 69.1)
    set_text(num, big)
    lab = clone("Texte 1")
    geo(lab, 690, y + 5.8, 220, 69.1)
    set_text(lab, small)
    lab.text_frame.paragraphs[0].runs[0].font.size = Pt(13)
renumber(obj)
src_tree = ref.notes_slide.shapes._spTree
dst_tree = obj.notes_slide.shapes._spTree
for el in list(dst_tree)[2:]:
    dst_tree.remove(el)
for el in list(src_tree)[2:]:
    dst_tree.append(copy.deepcopy(el))
obj.notes_slide.notes_text_frame.text = (
    "Message : notre objectif d'investissement durable est le climat. Lichen Symbiose Climat est classé "
    "Article 9 SFDR, au titre de l'article 9.3 : réduire les émissions de carbone, avec l'indice MSCI World "
    "Climate Paris Aligned comme référence.\n\n"
    "Quatre engagements mesurables, vérifiés sur le portefeuille final : une température implicite sous 2 °C "
    "(nous sommes à 1,69 °C, contre 2,40 °C pour le marché) ; une empreinte et une intensité carbone au moins "
    "deux fois plus faibles que le MSCI World, l'exigence des indices Paris-Aligned ; un chiffre d'affaires vert "
    "au moins 1,5 fois celui du marché, pour financer les solutions ; et 100 % d'investissements durables.\n\n"
    "Le mot « Climat » dans le nom nous engage, selon les orientations de l'ESMA sur les noms de fonds, à "
    "appliquer les exclusions Paris-Aligned : nous les appliquons.\n\n"
    "Notre conviction : la double durabilité. Chaque entreprise doit être durable et solide financièrement. "
    "Transition : voyons comment nous sélectionnons ces entreprises, en commençant par six filtres "
    "extra-financiers.")

# ---------------------------------------------------------------- 7. nouvel ordre
lst = p.slides._sldIdLst
ids = list(lst)            # ordre V2 (19 slides) + nouvelle slide en dernier
new = ids[19]
order = [ids[0], new, ids[1], ids[9], ids[10]] + ids[11:19] + ids[2:8]
dropped = ids[8]           # doublon de la vue d'ensemble
p.part.drop_rel(dropped.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"))
for el in ids:
    lst.remove(el)
for el in order:
    lst.append(el)

p.save(DST)
print("ok :", len(order), "slides ->", DST)
