"""Mise en forme des deux livrables Excel (aucune valeur modifiée).

Usage : python mettre_en_forme_excel.py dossier_resultats
"""
import datetime as dt
import sys
from pathlib import Path

import openpyxl
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, Font, PatternFill

DOSSIER = Path(sys.argv[1])
VERT_FORET = "16261D"
FOND_CARTE = "EEF0E8"
PCT, PCT2, DEC1, DEC2 = "0.0%", "0.00%", "0.0", "0.00"

# formats par feuille : {nom de colonne (ligne d'en-tête) : format}
COLONNES = {
    "Portefeuille": {"Poids": PCT2, "Score vert": DEC1, "Score financier": DEC1, "Température (°C)": DEC1,
                     "CA vert (%)": DEC1, "Intensité S1+2": DEC1, "Empreinte S1+2+3": DEC1,
                     "Volatilité 5 ans": PCT},
    "Secteurs": {"Fonds": PCT, "MSCI World": PCT, "Écart (pts)": DEC1},
    "Régions": {"Fonds": PCT, "MSCI World": PCT, "Écart (pts)": DEC1},
    "Performance par année": {"*": PCT},
    "Choix de la poche verte": {"Poche verte": "0%", "Tracking error": PCT2, "Température": DEC2,
                                "CA vert (%)": DEC1},
    "classement_lichen": {"*num": DEC1, "poids_indice": "0.000", "ITR": DEC1},
    "entonnoir_filtres": {"*num": DEC1},
    "entonnoir_financier": {"*num": DEC1},
    "tableau_exclusions": {"*num": DEC1},
}
# formats par ligne (étiquette en colonne A) : {étiquette : format}
LIGNES = {
    "Poches": {"Poids": "0%", "Volatilité 5 ans": PCT, "*": DEC1, "Lignes": "0"},
    "Résultats extra-financiers": {"*": DEC2, "@Écart": "+0%;-0%"},
    "Performance": {"Sharpe": DEC2, "*": PCT},
}


def style_entete(ws, ligne):
    for c in ws[ligne]:
        if c.value is not None or c.column > 1:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor=VERT_FORET)
            c.alignment = Alignment(vertical="center", wrap_text=True)


def largeurs(ws):
    for col in ws.iter_cols(min_row=1, max_row=min(ws.max_row, 400)):
        long = 0
        for c in col:
            v = c.value
            if v is None:
                continue
            if isinstance(v, float):
                n = 10
            elif isinstance(v, dt.datetime):
                n = 11
            else:
                n = len(str(v))
            long = max(long, n)
        ws.column_dimensions[get_column_letter(col[0].column)].width = min(max(long + 2, 8), 60)


def traiter(path):
    wb = openpyxl.load_workbook(path)
    for ws in wb:
        # en-tête : 1re ligne ; la feuille Performance a deux lignes d'en-tête
        nb_entete = 2 if ws.title == "Performance" else 1
        for r in range(1, nb_entete + 1):
            style_entete(ws, r)
        ws.freeze_panes = ws.cell(row=nb_entete + 1, column=2 if ws.max_column > 6 else 1)
        entete = {c.value: c.column for c in ws[nb_entete]}

        regles = COLONNES.get(ws.title, {})
        for nom, fmt in regles.items():
            if nom.startswith("*"):
                continue
            if nom in entete:
                for (c,) in ws.iter_rows(min_row=nb_entete + 1, min_col=entete[nom], max_col=entete[nom]):
                    if isinstance(c.value, (int, float)):
                        c.number_format = fmt
        if "*" in regles or "*num" in regles:
            fmt = regles.get("*", regles.get("*num"))
            for row in ws.iter_rows(min_row=nb_entete + 1, min_col=2):
                for c in row:
                    if isinstance(c.value, float) and c.number_format == "General":
                        c.number_format = fmt

        if ws.title in LIGNES:
            regles = LIGNES[ws.title]
            for row in ws.iter_rows(min_row=nb_entete + 1):
                etiquette = str(row[0].value or "")
                fmt = next((f for k, f in regles.items() if not k.startswith(("*", "@")) and etiquette.startswith(k)),
                           regles["*"])
                for c in row[1:]:
                    if isinstance(c.value, (int, float)):
                        col_nom = ws.cell(row=nb_entete, column=c.column).value
                        c.number_format = regles.get("@" + str(col_nom), fmt)

        for row in ws.iter_rows(min_row=nb_entete + 1, max_col=1):
            for c in row:
                if isinstance(c.value, dt.datetime):
                    c.number_format = "yyyy-mm-dd"
        if ws.title in ("cours_mensuels", "change_mensuel", "estr"):
            for row in ws.iter_rows(min_row=2, min_col=2):
                for c in row:
                    if isinstance(c.value, float):
                        c.number_format = "0.0000"
        largeurs(ws)
    wb.save(path)
    print("mis en forme :", path.name)


for nom in ("Lichen_Portefeuille.xlsx", "Lichen_Donnees_complementaires.xlsx"):
    traiter(DOSSIER / nom)
