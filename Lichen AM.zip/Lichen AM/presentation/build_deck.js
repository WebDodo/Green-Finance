// Deck Lichen AM — slides construites au fil du projet
const pptxgen = require("pptxgenjs");
const path = require("path");
const { applyTheme } = require("/root/.claude/skills/synced/0f8d2a8f-cabf-4354-83f8-bd1227c781e6_b4ed49db-9add-4ea2-b774-3ff55cab466d/pptx/scripts/apply_theme.js");

const FIG = path.join(__dirname, "..", "resultats", "figures");
const OUT = path.join(__dirname, "Lichen_AM_Presentation.pptx");

const THEME = {
  name: "Lichen",
  headFontFace: "Cambria",
  bodyFontFace: "Calibri",
  colors: {
    dk1: "16261D", lt1: "FFFFFF", dk2: "3C4A42", lt2: "EEF2EA",
    accent1: "4F7F52", accent2: "C2D46A", accent3: "8FB39A", accent4: "D9A441",
    accent5: "2A78D6", accent6: "C23B3A", hlink: "4F7F52", folHlink: "3C4A42",
  },
};

(async () => {
  const pres = new pptxgen();
  pres.layout = "LAYOUT_WIDE"; // 13,33 x 7,5
  pres.author = "Lichen AM";
  pres.title = "Lichen Symbiose Climat";
  pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
  const C = pres.SchemeColor;

  // ---------- Layouts ----------
  pres.defineSlideMaster({
    title: "COUVERTURE",
    background: { color: C.text1 },
    objects: [
      { placeholder: { options: { name: "title", type: "title", x: 0.8, y: 1.95, w: 7.8, h: 1.9,
          fontSize: 50, bold: true, color: C.background1, valign: "bottom", align: "left", margin: 0 }, text: "" } },
      { placeholder: { options: { name: "body", type: "body", x: 0.8, y: 4.05, w: 7.6, h: 0.6,
          fontSize: 20, color: C.accent2, align: "left", margin: 0 }, text: "" } },
    ],
  });
  pres.defineSlideMaster({
    title: "CONTENU",
    background: { color: C.background1 },
    margin: [0.5, 0.5, 0.6, 0.5],
    objects: [
      { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.35, w: 12.33, h: 0.85,
          fontSize: 34, bold: true, color: C.text1, valign: "middle", align: "left", margin: 0 }, text: "" } },
      { text: { text: "Lichen AM · Lichen Symbiose Climat · Projet universitaire, document à caractère promotionnel",
          options: { x: 0.5, y: 7.05, w: 10, h: 0.3, fontSize: 9, color: C.text2, margin: 0 } } },
    ],
    slideNumber: { x: 12.33, y: 7.05, w: 0.5, h: 0.3, fontSize: 9, color: C.text2, align: "right" },
  });


  const XR = 8.6, WR = 4.23;
  // Jauge d'entonnoir (remplace le fil d'Ariane) : ce qui reste de l'indice après le filtre, et ce que ce filtre retire en plus
  const fs = require("fs");
  const ENT = fs.readFileSync(path.join(__dirname, "..", "resultats", "entonnoir_filtres.csv"), "utf8").trim().split(/\r?\n/).slice(1)
    .map((l) => { const c = l.split(","); return { etape: c[0], resteN: +c[5], restePct: +c[6], plusN: +c[3], plusPct: +c[4] }; });
  const frNum = (x, d = 1) => x.toFixed(d).replace(".", ",");
  const frInt = (n) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  const jauge = (slide, titre, prevPct, curPct, curN, tag) => {
    const x0 = XR, w = WR;
    slide.addText(titre, { x: x0, y: 0.28, w, h: 0.25, fontSize: 10.5, color: C.text2, margin: 0, isTextBox: true, objectName: `Jauge ${tag} titre` });
    slide.addText([
      { text: `${frNum(curPct)} % de l'indice`, options: { bold: true, fontSize: 19, color: C.accent1, fontFace: THEME.headFontFace } },
      { text: `  ·  ${frInt(curN)} entreprises`, options: { fontSize: 12.5, color: C.text2 } },
    ], { x: x0, y: 0.52, w, h: 0.45, valign: "middle", margin: 0, isTextBox: true, objectName: `Jauge ${tag} reste` });
    slide.addShape(pres.shapes.RECTANGLE, { x: x0, y: 1.05, w, h: 0.13, fill: { color: C.background2 }, line: { type: "none" }, objectName: `Jauge ${tag} fond` });
    slide.addShape(pres.shapes.RECTANGLE, { x: x0, y: 1.05, w: w * curPct / 100, h: 0.13, fill: { color: C.accent1 }, line: { type: "none" }, objectName: `Jauge ${tag} barre` });
    if (prevPct - curPct < 0.05) return;
    slide.addShape(pres.shapes.RECTANGLE, { x: x0 + w * curPct / 100, y: 1.05, w: Math.max(w * (prevPct - curPct) / 100, 0.02), h: 0.13,
      fill: { color: C.accent6 }, line: { type: "none" }, objectName: `Jauge ${tag} retiré` });
    slide.addText(`−${frNum(prevPct - curPct)} pts`, { x: x0 + w * curPct / 100 - 0.6, y: 1.2, w: 1.2 + w * (prevPct - curPct) / 100, h: 0.2,
      fontSize: 9, bold: true, color: C.accent6, align: "center", margin: 0, isTextBox: true, objectName: `Jauge ${tag} retiré texte` });
  };
  const ENTF = fs.readFileSync(path.join(__dirname, "..", "resultats", "entonnoir_financier.csv"), "utf8").trim().split(/\r?\n/).slice(1)
    .map((l) => { const c = l.split(","); return { etape: c[0], seulN: +c[1], seulPct: +c[2], plusN: +c[3], plusPct: +c[4], resteN: +c[5], restePct: +c[6] }; });
  const filAriane = (slide, etape) => {
    const prev = ENT[etape - 1], cur = ENT[etape], x0 = XR, w = WR;
    slide.addText(`Étape ${etape} sur 6 · après ce filtre, il reste`, { x: x0, y: 0.28, w, h: 0.25, fontSize: 10.5,
      color: C.text2, margin: 0, isTextBox: true, objectName: "Entonnoir titre" });
    slide.addText([
      { text: `${frNum(cur.restePct)} % de l'indice`, options: { bold: true, fontSize: 19, color: C.accent1, fontFace: THEME.headFontFace } },
      { text: `  ·  ${frInt(cur.resteN)} entreprises`, options: { fontSize: 12.5, color: C.text2 } },
    ], { x: x0, y: 0.52, w, h: 0.45, valign: "middle", margin: 0, isTextBox: true, objectName: "Entonnoir reste" });
    slide.addShape(pres.shapes.RECTANGLE, { x: x0, y: 1.05, w, h: 0.13, fill: { color: C.background2 }, line: { type: "none" },
      objectName: "Entonnoir fond" });
    slide.addShape(pres.shapes.RECTANGLE, { x: x0, y: 1.05, w: w * cur.restePct / 100, h: 0.13, fill: { color: C.accent1 },
      line: { type: "none" }, objectName: "Entonnoir reste barre" });
    slide.addShape(pres.shapes.RECTANGLE, { x: x0 + w * cur.restePct / 100, y: 1.05, w: Math.max(w * (prev.restePct - cur.restePct) / 100, 0.02),
      h: 0.13, fill: { color: C.accent6 }, line: { type: "none" }, objectName: "Entonnoir retiré barre" });
    slide.addText(`−${frNum(cur.plusPct)} pts`, { x: x0 + w * cur.restePct / 100 - 0.6, y: 1.2, w: 1.2 + w * (prev.restePct - cur.restePct) / 100, h: 0.2,
      fontSize: 9, bold: true, color: C.accent6, align: "center", margin: 0, isTextBox: true, objectName: "Entonnoir retiré" });
  };

  // ---------- Slide 1 : couverture ----------
  pres.addSection({ title: "Introduction" });
  let s = pres.addSlide({ masterName: "COUVERTURE", sectionTitle: "Introduction" });
  // Motif : amas de cercles, comme un thalle de lichen
  const amas = [
    [9.55, 1.15, 2.6, C.accent1, 15], [11.35, 2.55, 1.6, C.accent2, 10], [9.25, 3.65, 1.9, C.accent3, 35],
    [10.95, 4.35, 1.15, C.accent2, 30], [8.75, 2.65, 0.85, C.accent2, 0], [11.9, 1.25, 0.7, C.accent3, 20],
    [10.35, 5.45, 0.75, C.accent1, 25], [12.15, 3.95, 0.45, C.accent2, 45],
  ];
  amas.forEach(([x, y, d, col, t], i) =>
    s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: col, transparency: t },
      line: { type: "none" }, objectName: `Lichen cercle ${i + 1}` }));
  s.addText("LICHEN ASSET MANAGEMENT", { x: 0.8, y: 1.3, w: 7.6, h: 0.45, fontSize: 14, bold: true,
    charSpacing: 4, color: C.accent3, margin: 0, isTextBox: true, objectName: "Société de gestion" });
  s.addText([{ text: "Lichen Symbiose", options: { breakLine: true } }, { text: "Climat", options: { color: C.accent2 } }], { placeholder: "title" });
  s.addText("Actions Monde · SFDR Article 9", { placeholder: "body" });
  s.addText("La performance et le climat, en symbiose.", { x: 0.8, y: 4.95, w: 7.6, h: 0.6, fontSize: 24, italic: true,
    fontFace: THEME.headFontFace, color: C.background1, margin: 0, isTextBox: true, objectName: "Slogan" });
  s.addText("Projet final · Finance durable · Université Paris-Dauphine · Novembre 2026", {
    x: 0.8, y: 6.45, w: 8.5, h: 0.35, fontSize: 12, color: C.accent3, margin: 0, isTextBox: true, objectName: "Contexte" });
  s.addText("Société de gestion et fonds fictifs. Document à caractère promotionnel.", {
    x: 0.8, y: 6.8, w: 8.5, h: 0.3, fontSize: 10, color: C.accent3, margin: 0, isTextBox: true, objectName: "Mention AMF" });
  s.addNotes(
    "Le lichen est un bio-indicateur : il ne pousse que là où l'air est sain. C'est la philosophie de Lichen AM : mesurer avant d'investir, et ne jamais se fier à un seul indicateur.\n\n" +
    "Un lichen n'est pas un organisme unique : c'est une symbiose entre un champignon, qui apporte la structure et la résistance, et une algue, qui capte l'énergie du soleil par la photosynthèse. Ensemble, ils survivent là où aucun des deux ne survivrait seul. Notre fonds a la même architecture : une poche Noyau, qui porte la performance et l'équilibre (les meilleures entreprises en financier), et une poche Photosynthèse, qui finance les solutions de la transition (les meilleures en vert). Leur taille est fixée à la pondération. Toutes les lignes sont des investissements durables au sens de l'Article 9.\n\n" +
    "Lichen Symbiose Climat est un fonds actions monde, classé Article 9 SFDR : il poursuit un objectif d'investissement durable, la réduction des émissions (article 9.3), " +
    "avec l'indice MSCI World Climate Paris Aligned comme référence. Le mot « Climat » dans le nom nous engage, selon les orientations de l'ESMA, à appliquer les exclusions Paris-Aligned : nous les appliquons."
  );

  // ---------- Slide 2 : le constat ----------
  s = pres.addSlide({ masterName: "CONTENU", sectionTitle: "Introduction" });
  s.addText("Une seule note ESG ne suffit pas", { placeholder: "title" });
  s.addImage({ path: path.join(FIG, "G1_correlations_metriques_slide.png"), x: 0.5, y: 1.4, w: 6.18, h: 5.25,
    altText: "Matrice des corrélations de rang entre 15 métriques extra-financières MSCI du MSCI World au 31/12/2024, regroupées en notation, climat, controverses, ODD climat et solutions. Corrélation moyenne 0,14.",
    objectName: "Matrice de corrélation" });

  const cartes = [
    ["0,14", "corrélation moyenne entre 15 métriques extra-financières, toutes issues de MSCI"],
    ["34 %", "des entreprises notées AAA ont une trajectoire au-dessus de 2 °C (68 sur 201)"],
    ["−0,32", "entre part d'activité verte et faible carbone : ceux qui produisent les solutions émettent"],
  ];
  const X = 7.0, W = 5.83;
  cartes.forEach(([chiffre, texte], i) => {
    const y = 1.45 + i * 1.32;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: X, y, w: W, h: 1.12, rectRadius: 0.12,
      fill: { color: C.background2 }, line: { type: "none" }, objectName: `Carte ${i + 1}` });
    s.addShape(pres.shapes.OVAL, { x: X + 0.25, y: y + 0.31, w: 0.5, h: 0.5,
      fill: { color: i === 2 ? C.accent2 : C.accent1, transparency: 0 }, line: { type: "none" }, objectName: `Pastille ${i + 1}` });
    s.addText(chiffre, { x: X + 0.95, y: y + 0.08, w: 1.75, h: 0.96, fontSize: 30, bold: true,
      fontFace: THEME.headFontFace, color: C.text1, valign: "middle", margin: 0, isTextBox: true, objectName: `Chiffre ${i + 1}` });
    s.addText(texte, { x: X + 2.75, y: y + 0.08, w: W - 2.95, h: 0.96, fontSize: 14, color: C.text2,
      valign: "middle", margin: 0, isTextBox: true, objectName: `Texte ${i + 1}` });
  });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: X, y: 5.5, w: W, h: 1.3, rectRadius: 0.12,
    fill: { color: C.text1 }, line: { type: "none" }, objectName: "Encadré réponse" });
  s.addText([
    { text: "Notre réponse", options: { bold: true, color: C.accent2, fontSize: 14, breakLine: true } },
    { text: "Combiner des filtres complémentaires — gouvernance, controverses, température, carbone par secteur, ODD — plutôt que se fier à une seule mesure.",
      options: { color: C.background1, fontSize: 14 } },
  ], { x: X + 0.3, y: 5.6, w: W - 0.6, h: 1.1, valign: "middle", margin: 0, isTextBox: true, objectName: "Texte réponse" });
  s.addText("Source : MSCI, MSCI World au 31/12/2024. Corrélations de Spearman ; valeurs inférieures à 0,15 non affichées.", {
    x: 0.5, y: 6.72, w: 6.3, h: 0.25, fontSize: 9, color: C.text2, margin: 0, isTextBox: true, objectName: "Source" });
  s.addNotes(
    "Message : une note ESG, à elle seule, ne dit presque rien de l'impact climatique réel d'une entreprise.\n\n" +
    "Mots-clés : Aggregate Confusion · divergence des mesures · une seule métrique ne suffit pas · combiner les filtres · raisonner par secteur.\n\n" +
    "1. Corrélation moyenne de 0,14 entre 15 métriques extra-financières, alors qu'elles viennent toutes du même fournisseur (MSCI). " +
    "Pour comparaison : 0,54 entre agences de notation (Berg, Kölbel et Rigobon), 0,28 dans notre cas pratique n°1, 0,99 entre Moody's et S&P en notation crédit.\n" +
    "2. Être bien noté ne dit presque rien du climat : la note ESG est corrélée à 0,18 avec la température implicite et à 0,04 avec l'intensité carbone. " +
    "34 % des entreprises notées AAA (68 sur 201) ont une trajectoire au-dessus de 2 °C : par exemple Hess (pétrolier, AAA, 6 °C) ou Toray Industries (AAA, 5,2 °C). 9 AAA ont aussi une controverse grave (Unilever, Danone, Gilead).\n" +
    "3. Le paradoxe vert : la part de chiffre d'affaires vert est corrélée négativement à un faible carbone (−0,32). Les producteurs de solutions (électricité renouvelable, matériaux, équipements) émettent eux-mêmes beaucoup. " +
    "Un filtre carbone global les exclurait : nous filtrons donc le carbone au sein de chaque secteur.\n" +
    "4. Seules familles cohérentes : intensité et empreinte carbone (0,91), et les ODD climatiques 7, 12 et 13 entre eux (0,59 à 0,70).\n\n" +
    "Transition : c'est pourquoi Lichen Climat empile des filtres complémentaires, chacun rattrapant ce que les autres ne voient pas."
  );


  // ---------- Slide 3 : filtre 1, bonne gouvernance ----------
  pres.addSection({ title: "Filtres extra-financiers" });
  s = pres.addSlide({ masterName: "CONTENU", sectionTitle: "Filtres extra-financiers" });
  s.addText("Filtre 1 · Bonne gouvernance", { placeholder: "title" });
  filAriane(s, 1);

  s.addImage({ path: path.join(FIG, "G2_bonne_gouvernance_slide.png"), x: 0.5, y: 1.5, w: 7.7, h: 4.8,
    altText: "Nombre d'entreprises du MSCI World par note MSCI ESG : 201 AAA, 447 AA, 328 A, 160 BBB, 84 BB conservées ; 15 B, 2 CCC et 10 sans note exclues.",
    objectName: "Graphique notes ESG" });
  s.addText("Source : MSCI, MSCI World au 31/12/2024. Nombre d'entreprises par note et part de l'indice.", {
    x: 0.5, y: 6.45, w: 7.7, h: 0.25, fontSize: 9, color: C.text2, margin: 0, isTextBox: true, objectName: "Source G2" });

  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: XR, y: 1.5, w: WR, h: 2.25, rectRadius: 0.12,
    fill: { color: C.text1 }, line: { type: "none" }, objectName: "Encadré règle" });
  s.addText([
    { text: "La règle", options: { bold: true, color: C.accent2, fontSize: 14, breakLine: true } },
    { text: "SFDR exige une « bonne gouvernance » sans fixer de seuil. Nous excluons les entreprises que MSCI classe retardataires (B, CCC) et celles sans note.",
      options: { color: C.background1, fontSize: 14 } },
  ], { x: XR + 0.3, y: 1.6, w: WR - 0.6, h: 2.05, valign: "middle", margin: 0, isTextBox: true, objectName: "Texte règle" });

  [["27", "entreprises exclues sur 1\u00a0247"], ["2,6 %", "de l'indice, dont 1,9\u00a0% pour Meta (B)"]].forEach(([chiffre, texte], i) => {
    const y = 3.95 + i * 1.2;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: XR, y, w: WR, h: 1.0, rectRadius: 0.12,
      fill: { color: C.background2 }, line: { type: "none" }, objectName: `Carte G2 ${i + 1}` });
    s.addText(chiffre, { x: XR + 0.3, y: y + 0.05, w: 1.45, h: 0.9, fontSize: 30, bold: true,
      fontFace: THEME.headFontFace, color: C.text1, valign: "middle", margin: 0, isTextBox: true, objectName: `Chiffre G2 ${i + 1}` });
    s.addText(texte, { x: XR + 1.8, y: y + 0.05, w: WR - 2.0, h: 0.9, fontSize: 14, color: C.text2,
      valign: "middle", margin: 0, isTextBox: true, objectName: `Texte G2 ${i + 1}` });
  });
  s.addText("Un socle réglementaire, pas encore une sélection.", { x: XR, y: 6.4, w: WR, h: 0.35, fontSize: 14,
    italic: true, fontFace: THEME.headFontFace, color: C.accent1, margin: 0, isTextBox: true, objectName: "Chute G2" });
  s.addNotes(
    "Message : premier filtre Article 9, la bonne gouvernance. C'est un socle réglementaire, peu sélectif.\n\n" +
    "Pourquoi : l'article 2.17 de SFDR exige que chaque investissement durable applique des pratiques de bonne gouvernance (structures de gestion saines, relations avec le personnel, rémunération, conformité fiscale), sans fixer de seuil. Chaque société de gestion choisit sa méthode et la documente.\n\n" +
    "Notre règle : note MSCI ESG au moins égale à BB. MSCI classe lui-même ses notes en leaders (AAA, AA), dans la moyenne (A, BBB, BB) et retardataires (B, CCC). Nous excluons les retardataires et les entreprises sans note (« on n'investit pas dans ce qu'on ne mesure pas »).\n\n" +
    "Résultat : 27 entreprises exclues sur 1 247 (15 B, 2 CCC, 10 sans note), soit 2,6 % de l'indice. Meta Platforms (B) pèse à elle seule 1,9 % de l'indice. Autres exemples : Palantir, Volkswagen, Philips, Porsche SE, Southwest Airlines, Dassault Aviation (toutes B). Sans note : Spotify, Nu Holdings, Coupang.\n\n" +
    "Transition : le MSCI World est majoritairement noté A et AA ; la vraie sélection viendra des filtres suivants, à commencer par les controverses (ne pas nuire)."
  );

  // ---------- Slide 4 : filtre 2, ne pas nuire (DNSH) ----------
  s = pres.addSlide({ masterName: "CONTENU", sectionTitle: "Filtres extra-financiers" });
  s.addText("Filtre 2 · Ne pas nuire", { placeholder: "title" });
  filAriane(s, 2);
  s.addImage({ path: path.join(FIG, "G3_dnsh_controverses_slide.png"), x: 0.5, y: 1.5, w: 7.85, h: 3.22,
    altText: "Distribution des notes de controverse MSCI par pilier. Exclues sous 2/10 : 28 en environnement (4,1 % de l'indice), 149 en social (27,9 %), 35 en gouvernance (6,6 %).",
    objectName: "Graphique controverses" });

  s.addText("Les géants écartés pour controverse grave", { x: 0.5, y: 5.05, w: 7.85, h: 0.35, fontSize: 14, bold: true,
    color: C.text1, margin: 0, isTextBox: true, objectName: "Titre géants" });
  const geants = [["Apple", "S"], ["Amazon", "S"], ["Meta", "S"], ["Tesla", "S"],
                  ["JPMorgan", "G"], ["Berkshire", "S"], ["ExxonMobil", "E, S"], ["UnitedHealth", "S, G"]];
  geants.forEach(([nom, pil], i) => {
    const x = 0.5 + (i % 4) * 1.99, y = 5.5 + Math.floor(i / 4) * 0.6;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 1.86, h: 0.48, rectRadius: 0.24,
      fill: { color: C.background2 }, line: { type: "none" }, objectName: `Pastille ${nom}` });
    s.addText([{ text: nom, options: { bold: true, color: C.text1 } }, { text: `  ${pil}`, options: { color: C.accent6 } }],
      { x, y, w: 1.86, h: 0.48, fontSize: 13, align: "center", valign: "middle", margin: 0, isTextBox: true, objectName: `Texte ${nom}` });
  });

  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: XR, y: 1.5, w: WR, h: 2.25, rectRadius: 0.12,
    fill: { color: C.text1 }, line: { type: "none" }, objectName: "Encadré règle DNSH" });
  s.addText([
    { text: "La règle", options: { bold: true, color: C.accent2, fontSize: 14, breakLine: true } },
    { text: "Un investissement durable ne doit causer aucun préjudice important. Une seule controverse grave (E, S ou G sous 2/10) suffit à exclure.",
      options: { color: C.background1, fontSize: 14 } },
  ], { x: XR + 0.3, y: 1.6, w: WR - 0.6, h: 2.05, valign: "middle", margin: 0, isTextBox: true, objectName: "Texte règle DNSH" });
  [["189", "exclues sur tout le MSCI, dont 174 en plus du filtre\u00a01"], ["33,6 %", "de l'indice, dont 31,4\u00a0% en plus"]].forEach(([chiffre, texte], i) => {
    const y = 3.95 + i * 1.2;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: XR, y, w: WR, h: 1.0, rectRadius: 0.12,
      fill: { color: C.background2 }, line: { type: "none" }, objectName: `Carte G3 ${i + 1}` });
    s.addText(chiffre, { x: XR + 0.3, y: y + 0.05, w: 1.6, h: 0.9, fontSize: 30, bold: true,
      fontFace: THEME.headFontFace, color: C.text1, valign: "middle", margin: 0, isTextBox: true, objectName: `Chiffre G3 ${i + 1}` });
    s.addText(texte, { x: XR + 1.95, y: y + 0.05, w: WR - 2.15, h: 0.9, fontSize: 14, color: C.text2,
      valign: "middle", margin: 0, isTextBox: true, objectName: `Texte G3 ${i + 1}` });
  });
  s.addText("4 des « Magnificent 7 » sortent ici.", { x: XR, y: 6.4, w: WR, h: 0.35, fontSize: 14,
    italic: true, fontFace: THEME.headFontFace, color: C.accent1, margin: 0, isTextBox: true, objectName: "Chute G3" });
  s.addNotes(
    "Message : deuxième condition de l'Article 9, ne pas nuire (DNSH). C'est le premier filtre vraiment sélectif.\n\n" +
    "Pourquoi : selon l'article 2.17 de SFDR, un investissement durable ne doit causer de préjudice important à aucun objectif environnemental ou social. On le vérifie par les incidences négatives, notamment le PAI 10 (violations du Pacte mondial de l'ONU et des principes de l'OCDE).\n\n" +
    "Notre règle : MSCI note les controverses de 0 (drapeau rouge, très grave) à 10 (aucune) sur trois piliers. On exclut dès qu'un pilier est sous 2/10 : un bon score ailleurs ne compense pas une controverse grave. Pas de donnée = exclusion.\n\n" +
    "Résultat : 189 entreprises exclues (15 % de l'univers), 33,6 % de l'indice. Le social domine : 149 entreprises, 27,9 % de l'indice (conditions de travail, protection des données, sécurité des produits). Environnement : 28 ; gouvernance : 35. 152 sont exclues sur un seul pilier, 27 sur deux, 2 sur les trois, 8 faute de données.\n\n" +
    "Exemples : Apple, Amazon, Meta, Tesla, Berkshire Hathaway, Costco, Johnson & Johnson (social) ; JPMorgan, Bank of America (gouvernance) ; UnitedHealth, Walmart, Wells Fargo (social et gouvernance) ; ExxonMobil (environnement et social) ; Procter & Gamble (environnement).\n\n" +
    "Cumul des deux filtres Article 9 : 201 entreprises exclues, 34 % de l'indice ; il en reste 1 046.\n\n" +
    "4 des « Magnificent 7 » sortent à ce filtre : Apple, Amazon, Meta et Tesla.\n\nTransition : après les exigences de l'Article 9, place à notre objectif climat : l'alignement sur l'Accord de Paris."
  );

  // ---------- Slide 5 : filtre 3, Accord de Paris ----------
  s = pres.addSlide({ masterName: "CONTENU", sectionTitle: "Filtres extra-financiers" });
  s.addText("Filtre 3 · Accord de Paris", { placeholder: "title" });
  filAriane(s, 3);
  s.addImage({ path: path.join(FIG, "G4_temperature_secteurs_slide.png"), x: 0.5, y: 1.4, w: 7.75, h: 3.57,
    altText: "Température implicite de chaque entreprise du MSCI World triée par secteur, avec le seuil d'exclusion à 3,1 °C. Part exclue : 2 % en communication jusqu'à 65 % dans l'énergie.",
    objectName: "Graphique températures" });
  [["270", "exclues sur tout le MSCI, dont 213 en plus des filtres 1\u00a0et\u00a02"], ["15,7 %", "de l'indice, dont 10,2\u00a0% en plus"], ["1,86 °C", "température des 833 restantes, contre 2,40\u00a0°C pour le marché"]]
    .forEach(([chiffre, texte], i) => {
      const x = 0.5 + i * 2.66, y = 5.15, w = i === 2 ? 2.53 : 2.5;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h: 1.6, rectRadius: 0.12,
        fill: { color: C.background2 }, line: { type: "none" }, objectName: `Carte G4 ${i + 1}` });
      s.addText(chiffre, { x: x + 0.25, y: y + 0.15, w: w - 0.5, h: 0.65, fontSize: 28, bold: true,
        fontFace: THEME.headFontFace, color: C.text1, valign: "middle", margin: 0, isTextBox: true, objectName: `Chiffre G4 ${i + 1}` });
      s.addText(texte, { x: x + 0.25, y: y + 0.8, w: w - 0.5, h: 0.75, fontSize: i === 2 ? 12 : 14, color: C.text2,
        valign: "top", margin: 0, isTextBox: true, objectName: `Texte G4 ${i + 1}` });
    });

  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: XR, y: 1.5, w: WR, h: 2.0, rectRadius: 0.12,
    fill: { color: C.text1 }, line: { type: "none" }, objectName: "Encadré règle ITR" });
  s.addText([
    { text: "La règle", options: { bold: true, color: C.accent2, fontSize: 14, breakLine: true } },
    { text: "Exclure les 20 % d'entreprises à la trajectoire la plus chaude : température implicite MSCI de 3,1\u00a0°C ou plus.",
      options: { color: C.background1, fontSize: 14 } },
  ], { x: XR + 0.3, y: 1.6, w: WR - 0.6, h: 1.8, valign: "middle", margin: 0, isTextBox: true, objectName: "Texte règle ITR" });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: XR, y: 3.7, w: WR, h: 2.45, rectRadius: 0.12,
    fill: { color: C.background2 }, line: { type: "none" }, objectName: "Encadré pourquoi global" });
  s.addText([
    { text: "Pourquoi un seuil global ?", options: { bold: true, color: C.text1, fontSize: 14, breakLine: true } },
    { text: "La température est comparable d'un secteur à l'autre. Un seuil par secteur garderait 78 entreprises au-dessus de 3,1\u00a0°C, jusqu'à 6,1\u00a0°C. L'équilibre sectoriel se règle à la pondération.",
      options: { color: C.text2, fontSize: 14 } },
  ], { x: XR + 0.3, y: 3.8, w: WR - 0.6, h: 2.25, valign: "middle", margin: 0, isTextBox: true, objectName: "Texte pourquoi global" });
  s.addText("Les producteurs de solutions ne sont pas pénalisés.", { x: XR, y: 6.35, w: WR, h: 0.4, fontSize: 14,
    italic: true, fontFace: THEME.headFontFace, color: C.accent1, margin: 0, isTextBox: true, objectName: "Chute G4" });
  s.addNotes(
    "Message : troisième filtre, le cœur de notre objectif climat (Article 9.3). On écarte les trajectoires incompatibles avec l'Accord de Paris.\n\n" +
    "La température implicite (ITR) de MSCI : la hausse de température mondiale en 2100 si toute l'économie émettait comme l'entreprise, en tenant compte de ses objectifs de réduction. Mesure prospective et comparable entre secteurs. Le MSCI World pondéré est à 2,40 °C.\n\n" +
    "Notre règle (celle retenue par le cours depuis 2024) : exclure les 20 % les plus chaudes, soit 3,1 °C ou plus. L'ambition se complète au niveau du portefeuille : une contrainte de température sera imposée à la pondération.\n\n" +
    "Pourquoi un seuil global et pas par secteur : 3 °C représente la même trajectoire pour une banque et pour un cimentier. Un quantile par secteur garderait 78 entreprises au-dessus de 3,1 °C (des matériaux et de l'énergie jusqu'à 6,1 °C) tout en excluant des entreprises technologiques à 2,5 °C. Le déséquilibre sectoriel (2 % exclues en communication, 65 % dans l'énergie) sera corrigé à la pondération par des bornes sur les poids sectoriels.\n\n" +
    "Le paradoxe vert : les entreprises avec au moins 20 % de chiffre d'affaires vert ne sont pas pénalisées (18 % exclues contre 22 % pour l'univers), car la température regarde la trajectoire, pas seulement les émissions actuelles. Exemples exclus malgré tout : NextEra (4,3 °C, encore beaucoup de gaz), Siemens Energy.\n\n" +
    "Exemples d'exclus : ExxonMobil (4,1 °C), Chevron (5,9 °C), Costco (3,7 °C), Linde, General Electric, Booking (10 °C, plafond MSCI).\n\n" +
    "Cumul après trois filtres : 414 entreprises exclues (44 % de l'indice), il en reste 833 avec une température moyenne de 1,86 °C contre 2,40 °C pour le marché.\n\n" +
    "Transition : le nom « Climat » nous oblige aussi à appliquer les exclusions Paris-Aligned."
  );

  // ---------- Slide 6 : filtre 4, exclusions Paris-Aligned ----------
  s = pres.addSlide({ masterName: "CONTENU", sectionTitle: "Filtres extra-financiers" });
  s.addText("Filtre 4 · Exclusions Paris-Aligned", { placeholder: "title" });
  filAriane(s, 4);
  s.addImage({ path: path.join(FIG, "G5_exclusions_pab_slide.png"), x: 0.5, y: 1.5, w: 6.94, h: 3.65,
    altText: "Cascade des exclusions Paris-Aligned, chaque entreprise comptée une fois : pétrole et gaz 3,8 % (52), charbon 2,2 % (30), mines de charbon 0,5 % (9), électricité carbonée 0,3 % (2), distribution de gaz 0,1 % (6), armes controversées 0,6 % (5), tabac 0,6 % (5) ; total 8,0 % (109).",
    objectName: "Graphique PAB" });
  s.addText("Exemples d'exclus hors secteur Énergie", { x: 0.5, y: 5.35, w: 7.7, h: 0.35, fontSize: 14, bold: true,
    color: C.text1, margin: 0, isTextBox: true, objectName: "Titre exemples PAB" });
  ["Berkshire", "Glencore", "BHP", "Mitsubishi", "NextEra", "Philip Morris", "Lockheed Martin", "Duke Energy"].forEach((nom, i) => {
    const x = 0.5 + (i % 4) * 1.95, y = 5.8 + Math.floor(i / 4) * 0.55;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 1.82, h: 0.44, rectRadius: 0.22,
      fill: { color: C.background2 }, line: { type: "none" }, objectName: `Pastille PAB ${nom}` });
    s.addText(nom, { x, y, w: 1.82, h: 0.44, fontSize: 12, bold: true, color: C.text1, align: "center",
      valign: "middle", margin: 0, isTextBox: true, objectName: `Texte PAB ${nom}` });
  });

  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: XR, y: 1.5, w: WR, h: 1.95, rectRadius: 0.12,
    fill: { color: C.text1 }, line: { type: "none" }, objectName: "Encadré règle PAB" });
  s.addText([
    { text: "La règle", options: { bold: true, color: C.accent2, fontSize: 14, breakLine: true } },
    { text: "Un nom « Climat » impose les exclusions des indices Paris-Aligned (ESMA 2025, règlement 2020/1818).",
      options: { color: C.background1, fontSize: 14 } },
  ], { x: XR + 0.3, y: 1.6, w: WR - 0.6, h: 1.75, valign: "middle", margin: 0, isTextBox: true, objectName: "Texte règle PAB" });
  [["109", "exclues sur le MSCI, dont 33 en plus"], ["8,0 %", "de l'indice, dont 1,4\u00a0% en plus"]].forEach(([chiffre, texte], i) => {
    const x = XR + i * 2.17, w = 2.06;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 3.6, w, h: 1.15, rectRadius: 0.12,
      fill: { color: C.background2 }, line: { type: "none" }, objectName: `Carte PAB ${i + 1}` });
    s.addText(chiffre, { x: x + 0.2, y: 3.65, w: w - 0.4, h: 0.6, fontSize: 26, bold: true,
      fontFace: THEME.headFontFace, color: C.text1, valign: "middle", margin: 0, isTextBox: true, objectName: `Chiffre PAB ${i + 1}` });
    s.addText(texte, { x: x + 0.2, y: 4.25, w: w - 0.4, h: 0.4, fontSize: 13, color: C.text2,
      valign: "top", margin: 0, isTextBox: true, objectName: `Texte PAB ${i + 1}` });
  });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: XR, y: 4.9, w: WR, h: 1.4, rectRadius: 0.12,
    fill: { color: C.background2 }, line: { type: "none" }, objectName: "Encadré sources" });
  s.addText([
    { text: "Données externes pour le charbon", options: { bold: true, color: C.text1, fontSize: 13, breakLine: true } },
    { text: "Global Coal Exit List 2026 (urgewald) et Global Coal Mine Tracker (Global Energy Monitor).",
      options: { color: C.text2, fontSize: 13 } },
  ], { x: XR + 0.3, y: 4.95, w: WR - 0.6, h: 1.3, valign: "middle", margin: 0, isTextBox: true, objectName: "Texte sources" });
  s.addText("Plus strict que la règle : tout le secteur Énergie sort.", { x: XR, y: 6.45, w: WR, h: 0.35, fontSize: 13,
    italic: true, fontFace: THEME.headFontFace, color: C.accent1, margin: 0, isTextBox: true, objectName: "Chute PAB" });
  s.addNotes(
    "Message : quatrième filtre, imposé par le nom du fonds. Le mot « Climat » oblige, selon les orientations de l'ESMA sur le nom des fonds (2025), à appliquer les exclusions des indices Paris-Aligned (règlement délégué 2020/1818, article 12). Elles sont aussi cohérentes avec notre indice de référence, le MSCI World Climate Paris Aligned.\n\n" +
    "Accord de Paris et Paris-Aligned : l'Accord de Paris est le traité (objectif de température, filtre 3) ; le Paris-Aligned Benchmark est la norme européenne d'indice (exclusions, carbone −50 % puis −7 % par an).\n\n" +
    "Les règles et nos données :\n- Armes controversées et tabac : données MSCI (5 entreprises chacune).\n- Pétrole (≥ 10 % du CA) et gaz (≥ 50 %) : nos données n'ont pas la part du CA par énergie ; nous excluons tout le secteur Énergie (52 entreprises), plus strict que la règle, ainsi que les 7 distributeurs de gaz.\n- Charbon (≥ 1 % du CA) : la Global Coal Exit List d'urgewald donne la part du CA charbon (31 entreprises au-dessus de 1 %) ; le Global Coal Mine Tracker rattrape le charbon métallurgique et les maisons de commerce japonaises (participation d'au moins 10 % dans une mine en activité d'au moins 0,5 Mt/an : Mitsubishi, Itochu, Nippon Steel…).\n- Électricité carbonée (> 100 gCO2/kWh) : électriciens avec une intensité scope 1 d'au moins 1 000 tCO2e par million de dollars de CA (environ 100 g/kWh pour un prix de 100 $/MWh), sauf s'ils ont au moins 50 % de CA vert.\n- Violations du Pacte mondial : déjà couvertes par le DNSH (filtre 2).\n\n" +
    "Lecture du graphique en cascade : chaque entreprise est comptée une seule fois, dans la première règle qui l'exclut, de haut en bas. Les barres s'additionnent jusqu'au total. Comptées seules, les règles feraient 137 entreprises et 10,1 % car 26 entreprises relèvent de plusieurs règles (Southern : charbon et électricité carbonée ; Berkshire : charbon et mines).\n\nRésultat : 109 entreprises, 8,0 % de l'indice. Exemples hors Énergie : Berkshire Hathaway (charbon de ses centrales), BHP, Glencore, Mitsubishi, NextEra, Southern, Duke, Philip Morris, Lockheed Martin.\n\n" +
    "Cumul après quatre filtres : 447 entreprises exclues (45,6 % de l'indice), il en reste 800. 33 entreprises sont exclues uniquement par ces règles (Itochu, CSX, Schlumberger, General Dynamics…).\n\n" +
    "Transition : dernier étage, les exclusions complémentaires de Lichen (pilier E, carbone par secteur, ODD climatiques)."
  );

  // Cartes chiffres sous le graphique (3 cartes, la dernière foncée)
  const cartesBas = (slide, items, tag) => items.forEach(([chiffre, texte], i) => {
    const x = 0.5 + i * 2.66, y = 5.25, w = i === 2 ? 2.53 : 2.5;
    slide.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h: 1.5, rectRadius: 0.12,
      fill: { color: i === 2 ? C.text1 : C.background2 }, line: { type: "none" }, objectName: `Carte ${tag} ${i + 1}` });
    slide.addText(chiffre, { x: x + 0.25, y: y + 0.12, w: w - 0.5, h: 0.6, fontSize: 28, bold: true, fontFace: THEME.headFontFace,
      color: i === 2 ? C.accent2 : C.text1, valign: "middle", margin: 0, isTextBox: true, objectName: `Chiffre ${tag} ${i + 1}` });
    slide.addText(texte, { x: x + 0.25, y: y + 0.75, w: w - 0.5, h: 0.65, fontSize: 12.5, color: i === 2 ? C.background1 : C.text2,
      valign: "top", margin: 0, isTextBox: true, objectName: `Texte ${tag} ${i + 1}` });
  });
  // Deux encadrés à droite (foncé puis clair) et une chute
  const encadres = (slide, haut, bas, chute, tag) => {
    slide.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: XR, y: 1.5, w: WR, h: 2.2, rectRadius: 0.12,
      fill: { color: C.text1 }, line: { type: "none" }, objectName: `Encadré ${tag} 1` });
    slide.addText([
      { text: haut[0], options: { bold: true, color: C.accent2, fontSize: 14, breakLine: true } },
      { text: haut[1], options: { color: C.background1, fontSize: 13.5 } },
    ], { x: XR + 0.3, y: 1.6, w: WR - 0.6, h: 2.0, valign: "middle", margin: 0, isTextBox: true, objectName: `Texte encadré ${tag} 1` });
    slide.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: XR, y: 3.85, w: WR, h: 2.4, rectRadius: 0.12,
      fill: { color: C.background2 }, line: { type: "none" }, objectName: `Encadré ${tag} 2` });
    slide.addText([
      { text: bas[0], options: { bold: true, color: C.text1, fontSize: 14, breakLine: true } },
      { text: bas[1], options: { color: C.text2, fontSize: 13.5 } },
    ], { x: XR + 0.3, y: 3.95, w: WR - 0.6, h: 2.2, valign: "middle", margin: 0, isTextBox: true, objectName: `Texte encadré ${tag} 2` });
    slide.addText(chute, { x: XR, y: 6.4, w: WR, h: 0.35, fontSize: 13, italic: true, fontFace: THEME.headFontFace,
      color: C.accent1, margin: 0, isTextBox: true, objectName: `Chute ${tag}` });
  };

  // ---------- Slide 7 : filtre 5, carbone par secteur ----------
  s = pres.addSlide({ masterName: "CONTENU", sectionTitle: "Filtres extra-financiers" });
  s.addText("Filtre 5 · Carbone par secteur", { placeholder: "title" });
  filAriane(s, 5);
  s.addImage({ path: path.join(FIG, "G6_carbone_secteurs_slide.png"), x: 0.5, y: 1.45, w: 7.75, h: 3.62,
    altText: "Empreinte carbone scopes 1+2+3 de chaque entreprise du MSCI World, triée par secteur : en vert les conservées, en rouge les 94 exclues en plus par le filtre carbone (points pleins : empreinte ; cercles vides : intensité seulement), en gris celles déjà exclues par les filtres 1 à 4.",
    objectName: "Graphique carbone par secteur" });
  cartesBas(s, [["202", "exclues sur tout le MSCI, dont 94 en plus des filtres 1\u00a0à\u00a04"], ["12,2 %", "de l'indice, dont 3,9\u00a0% en plus"],
             ["706", "entreprises restantes (50,4\u00a0% de l'indice)"]], "G6");
  encadres(s, ["Carbone, comparé au secteur", "Les 10 % les plus émetteurs de chaque secteur sortent. Un électricien n'est comparé qu'à d'autres électriciens."],
              ["Deux mesures, une union", "Exclue si dans les 10 % pires en empreinte OU en intensité : 65 sur l'empreinte, 27 sur l'intensité seulement."],
              "Comparer chaque entreprise à ses pairs.", "G6");
  s.addNotes(
    "Message : cinquième filtre, un choix de gestion. On retire les plus gros émetteurs de chaque secteur, sans vider les secteurs qui émettent naturellement beaucoup.\n\n" +
    "La règle (figure 11 du cours) : dans chaque secteur, on fait deux listes, les 10 % les plus émetteurs en empreinte (tCO2e par million investi) et les 10 % les plus émetteurs en intensité (par million de chiffre d'affaires), scopes 1+2+3. On exclut l'union des deux listes : il suffit d'être dans l'une. L'union est plus stricte que l'intersection : une entreprise très polluante par rapport à son chiffre d'affaires ne passe pas grâce à une forte valorisation boursière.\n\n" +
    "Le seuil est calculé sur tout le MSCI World, comme dans le cours : 202 entreprises visées (12,2 % de l'indice), dont 108 déjà exclues par les filtres 1 à 4 (en gris). Le filtre en retire donc 94 de plus (3,9 % de l'indice), en rouge.\n\n" +
    "Lecture : un point = une entreprise, triée de la moins à la plus émettrice dans son secteur ; le chiffre en haut = exclusions nouvelles du secteur. Points rouges pleins : exclues pour leur empreinte (65, dont 26 aussi en intensité). Cercles vides : intensité seulement (27). 2 : donnée carbone manquante, exclues par prudence. L'Énergie et les Matériaux sont déjà presque entièrement gris : le filtre Paris-Aligned avait sorti leurs pires émetteurs. La version complète (empreinte et intensité) est dans le notebook.\n\n" +
    "Nous avons testé les trois exclusions complémentaires du cours (pilier E, carbone, ODD 7, 12 et 13). Après les filtres 1 à 4, le pilier E n'ajoutait que 27 petites entreprises (1,1 % de l'indice) et les ODD désalignés 9 (0,4 %) : seule l'exclusion carbone change réellement l'univers, nous l'avons retenue.\n\n" +
    "Transition : il reste 706 entreprises qui ne nuisent pas. Le dernier filtre vérifie qu'elles contribuent."
  );

  // ---------- Slide 8 : filtre 6, contribution ----------
  s = pres.addSlide({ masterName: "CONTENU", sectionTitle: "Filtres extra-financiers" });
  s.addText("Filtre 6 · Contribution", { placeholder: "title" });
  filAriane(s, 6);
  s.addImage({ path: path.join(FIG, "G7_contribution_slide.png"), x: 0.5, y: 1.5, w: 7.75, h: 3.46,
    altText: "Cascade des entreprises du MSCI World par porte de contribution : 82 par le CA vert, 276 de plus par la trajectoire, 406 de plus par les ODD ; 483 n'en passent aucune, dont 272 déjà exclues et 211 exclues en plus.",
    objectName: "Graphique contribution" });
  cartesBas(s, [["483", "exclues sur tout le MSCI, dont 211 en plus des filtres 1\u00a0à\u00a05"], ["31,6 %", "de l'indice, dont 10,0\u00a0% en plus"],
             ["495", "entreprises éligibles Article 9 (40,5 % de l'indice)"]], "G7");
  encadres(s, ["Contribuer, pas seulement ne pas nuire", "Chaque ligne doit passer une porte : 20 % de CA vert, ou trajectoire ≤ 1,5 °C, ou un ODD environnemental aligné."],
              ["Pourquoi trois portes ?", "Seules 82 entreprises du MSCI ont 20 % de CA vert. La trajectoire et les ODD mesurent aussi une contribution réelle."],
              "La définition du cours, appliquée ligne à ligne.", "G7");
  s.addNotes(
    "Message : sixième et dernier filtre, celui qui fait de nous un fonds Article 9. L'article 2.17 de SFDR exige qu'un investissement durable contribue à un objectif environnemental ou social, pas seulement qu'il ne nuise pas.\n\n" +
    "La règle, définition du cours (« 20 % de revenus dans des activités durables ou réduction d'émissions validée SBTi »), appliquée ligne à ligne : une entreprise contribue si elle passe au moins une porte. Porte 1 : au moins 20 % de chiffre d'affaires vert (technologies propres MSCI ou Taxonomie européenne). Porte 2 : température implicite ≤ 1,5 °C, proxy d'une trajectoire validée SBTi. Porte 3 : un ODD environnemental aligné (score MSCI ≥ 2 sur les ODD 6, 7, 11 à 15).\n\n" +
    "Lecture de la cascade : chaque entreprise du MSCI World est comptée une seule fois, dans la première porte qu'elle passe. 82 par le CA vert (15,2 % de l'indice), 276 de plus par la trajectoire, 406 de plus par les ODD. 483 n'en passent aucune (31,6 % de l'indice) : 272 étaient déjà exclues (en gris), 211 sont exclues en plus (10,0 % de l'indice, en rouge).\n\n" +
    "Pourquoi trois portes : seules 82 entreprises du MSCI World ont plus de 20 % de CA vert, trop peu pour construire un fonds monde diversifié. La poche Photosynthèse, elle, sélectionne les plus fortes contributions.\n\n" +
    "Bilan des six filtres : 752 entreprises exclues, 59,5 % de l'indice (le cours : 53 %). Il reste 495 entreprises éligibles Article 9, 40,5 % de l'indice. Parmi les dix premières capitalisations, NVIDIA, Microsoft, Alphabet et Eli Lilly sont éligibles ; Apple, Amazon, Meta, Tesla, Broadcom et JPMorgan sont exclues.\n\n" +
    "Transition : ces 495 entreprises ont le droit d'entrer dans le fonds ; reste à vérifier leur solidité financière, puis à choisir et à pondérer."
  );

  // ---------- Slide 9 : filtres financiers ----------
  pres.addSection({ title: "Filtres financiers" });
  s = pres.addSlide({ masterName: "CONTENU", sectionTitle: "Filtres financiers" });
  s.addText("Filtres financiers · Solidité", { placeholder: "title" });
  {
    const fin = ENTF[ENTF.length - 1];
    jauge(s, "Filtrage financier · après les 5 filtres, il reste", 100, fin.restePct, fin.resteN, "fin");
    const REGLES = {
      "Rentabilité": "Rentabilité du capital > 0 (ROE pour les banques) et marge nette > 0",
      "Bilan": "Dette ≤ 60 % de l'actif (70 % pour l'immobilier et les services aux collectivités)",
      "Risque": "Volatilité 5 ans hors des 10 % pires du secteur, chute maximale < 70 %",
      "Liquidité": "Poids dans le MSCI World ≥ 0,01 %",
      "Historique de cours": "Cours sur au moins 95 % des semaines de 2020 à 2024",
    };
    const COLS = [["Filtre", 0.5, 1.75, "left"], ["Règle", 2.3, 4.6, "left"], ["Exclues sur le MSCI", 7.0, 1.35, "center"],
                  ["En plus des précédents", 8.45, 1.35, "center"], ["Il reste (% de l'indice)", 9.95, 2.88, "left"]];
    const Y0 = 1.55, HH = 0.5, HR = 0.56;
    s.addShape(pres.shapes.RECTANGLE, { x: 0.5, y: Y0, w: 12.33, h: HH, fill: { color: C.text1 }, line: { type: "none" }, objectName: "Tableau fin entête" });
    COLS.forEach(([t, x, w, al]) => s.addText(t, { x: x + 0.08, y: Y0, w: w - 0.16, h: HH, fontSize: 11.5, bold: true, color: C.background1,
      align: al, valign: "middle", margin: 0, isTextBox: true, objectName: `Entête ${t}` }));
    ENTF.forEach((r, k) => {
      const y = Y0 + HH + k * HR, depart = k === 0;
      s.addShape(pres.shapes.RECTANGLE, { x: 0.5, y, w: 12.33, h: HR, fill: { color: k % 2 ? C.background1 : C.background2 },
        line: { type: "none" }, objectName: `Ligne fin ${k}` });
      const vals = [depart ? "MSCI World" : r.etape, depart ? "Univers de départ" : REGLES[r.etape],
                    depart ? "–" : frInt(r.seulN), depart ? "–" : frInt(r.plusN)];
      vals.forEach((v, j) => s.addText(v, { x: COLS[j][1] + 0.08, y, w: COLS[j][2] - 0.16, h: HR, fontSize: j === 1 ? 11.5 : 12.5,
        bold: j === 0 || j === 3, color: j === 3 && !depart ? C.accent6 : (j === 1 ? C.text2 : C.text1), align: COLS[j][3], valign: "middle",
        margin: 0, isTextBox: true, objectName: `Cellule fin ${k}-${j}` }));
      const bx = 10.03, bw = 1.6;
      s.addShape(pres.shapes.RECTANGLE, { x: bx, y: y + HR / 2 - 0.07, w: bw, h: 0.14, fill: { color: C.background2 }, line: { color: C.accent3, width: 0.5 },
        objectName: `Barre fond ${k}` });
      s.addShape(pres.shapes.RECTANGLE, { x: bx, y: y + HR / 2 - 0.07, w: bw * r.restePct / 100, h: 0.14, fill: { color: C.accent1 },
        line: { type: "none" }, objectName: `Barre reste ${k}` });
      s.addText([{ text: `${frNum(r.restePct)} %`, options: { bold: true, color: C.text1, fontSize: 12.5, breakLine: true } },
                 { text: `${frInt(r.resteN)} entr.`, options: { color: C.text2, fontSize: 9.5 } }],
        { x: 11.72, y, w: 1.05, h: HR, valign: "middle", margin: 0, isTextBox: true, objectName: `Reste fin ${k}` });
    });
    const yb = Y0 + HH + ENTF.length * HR + 0.25;
    [["Double durabilité", "Un fonds Article 9 doit aussi rester un bon placement : nous écartons les entreprises fragiles."],
     ["Comparé au secteur", "Le risque est jugé face aux pairs, comme le carbone : un secteur volatil n'est pas vidé."],
     ["Historique en semaines", "Mesuré en jours, il excluait 154 japonaises à cause de leurs jours fériés."]]
      .forEach(([t, d], i) => {
        const x = 0.5 + i * 4.16, w = 4.01;
        s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: yb, w, h: 6.75 - yb, rectRadius: 0.12, fill: { color: i === 0 ? C.text1 : C.background2 },
          line: { type: "none" }, objectName: `Carte fin ${i + 1}` });
        s.addText([{ text: t, options: { bold: true, fontSize: 13.5, color: i === 0 ? C.accent2 : C.text1, breakLine: true } },
                   { text: d, options: { fontSize: 12, color: i === 0 ? C.background1 : C.text2 } }],
          { x: x + 0.25, y: yb + 0.05, w: w - 0.5, h: 6.75 - yb - 0.1, valign: "middle", margin: 0, isTextBox: true, objectName: `Texte carte fin ${i + 1}` });
      });
  }
  s.addNotes(
    "Message : en parallèle des filtres extra-financiers, nous construisons un univers financier sur tout le MSCI World, comme dans le cours (« intersection des univers »). Aucune règle ne l'impose réglementairement, mais un fonds Article 9 doit rester un bon placement : c'est la double durabilité.\n\n" +
    "Lecture du tableau : chaque filtre est mesuré seul sur tout le MSCI World (colonne « Exclues sur le MSCI »), puis ce qu'il retire en plus des filtres précédents, et ce qui reste de l'indice. La barre verte fond de 100 % à 81,8 %.\n\n" +
    "Les règles :\n- Rentabilité : ROIC positif (ROE pour les financières) et marge nette positive. 112 entreprises.\n- Bilan : dette inférieure à 60 % des actifs, 70 % pour l'immobilier et les services aux collectivités (actifs lourds), pas de règle pour les financières dont la dette est le métier. 52 entreprises.\n- Risque : volatilité 5 ans hors des 10 % les plus volatiles de son secteur, et perte maximale sur 5 ans moins forte que −70 %. 171 entreprises.\n- Liquidité : poids d'au moins 0,01 % dans l'indice, pour un fonds à liquidité quotidienne. 147 petites capitalisations.\n- Historique de cours : cours Yahoo Finance sur au moins 95 % des semaines de 2020 à 2024, nécessaire pour mesurer le risque et la performance. 87 entreprises : titres sans cours (retirés de la cote) ou cotés après 2020 (introductions en bourse, scissions).\n\n" +
    "Point de méthode : mesuré en jours, l'historique excluait 276 entreprises, dont 154 japonaises sans aucune donnée manquante. La bourse de Tokyo a plus de jours fériés que les autres, et notre calendrier commun les comptait comme des trous. Mesuré en semaines, le biais disparaît.\n\n" +
    "Résultat : 825 entreprises solides financièrement, 81,8 % de l'indice.\n\nTransition : il reste à croiser les deux univers."
  );

  // ---------- Slide 10 : intersection des deux univers ----------
  s = pres.addSlide({ masterName: "CONTENU", sectionTitle: "Filtres financiers" });
  s.addText("Intersection · Durable et solide", { placeholder: "title" });
  {
    const CR = {};
    fs.readFileSync(path.join(__dirname, "..", "resultats", "croisement_univers.csv"), "utf8").trim().split(/\r?\n/).slice(3)
      .forEach((l) => { const c = l.split(","); CR[c[0]] = { exclN: +c[1], solN: +c[2], exclP: +c[3], solP: +c[4] }; });
    const el = CR["Éligible Article 9"], ex = CR["Exclue extra-financier"];
    jauge(s, "Après les filtres extra-financiers puis financiers, il reste", el.solP + el.exclP, el.solP, el.solN, "inter");
    const gx = 2.9, gy = 2.05, cw = 2.6, ch = 1.85, gap = 0.14;
    s.addText("Solide financièrement", { x: gx, y: 1.5, w: cw, h: 0.4, fontSize: 12.5, bold: true, color: C.text1, align: "center", valign: "bottom", margin: 0, isTextBox: true, objectName: "Col solide" });
    s.addText("Exclue par les filtres financiers", { x: gx + cw + gap, y: 1.5, w: cw, h: 0.4, fontSize: 12.5, bold: true, color: C.text2, align: "center", valign: "bottom", margin: 0, isTextBox: true, objectName: "Col exclue fin" });
    s.addText("Éligible Article 9", { x: 0.5, y: gy - 0.2, w: 2.25, h: ch, fontSize: 12.5, bold: true, color: C.text1, align: "right", valign: "middle", margin: 0, isTextBox: true, objectName: "Ligne éligible" });
    s.addText("Exclue par les filtres extra-financiers", { x: 0.5, y: gy + ch + gap - 0.2, w: 2.25, h: ch, fontSize: 12.5, bold: true, color: C.text2, align: "right", valign: "middle", margin: 0, isTextBox: true, objectName: "Ligne exclue ef" });
    const cell = (x, y, n, p, fonce, legende, tag) => {
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: cw, h: ch, rectRadius: 0.1, fill: { color: fonce ? C.text1 : C.background2 }, line: { type: "none" }, objectName: `Case ${tag}` });
      s.addText([{ text: frInt(n), options: { bold: true, fontSize: 28, fontFace: THEME.headFontFace, color: fonce ? C.accent2 : C.text1, breakLine: true } },
                 { text: `${frNum(p)} % de l'indice`, options: { fontSize: 12, color: fonce ? C.background1 : C.text2, breakLine: true } },
                 { text: legende, options: { fontSize: 10.5, italic: true, color: fonce ? C.accent2 : C.text2 } }],
        { x: x + 0.2, y, w: cw - 0.4, h: ch, valign: "middle", align: "center", margin: 0, isTextBox: true, objectName: `Texte case ${tag}` });
    };
    cell(gx, gy, el.solN, el.solP, true, "univers sélectionnable", "inter");
    cell(gx + cw + gap, gy, el.exclN, el.exclP, false, "durables mais fragiles", "fragiles");
    cell(gx, gy + ch + gap, ex.solN, ex.solP, false, "solides mais non durables", "non durables");
    cell(gx + cw + gap, gy + ch + gap, ex.exclN, ex.exclP, false, "ni l'un ni l'autre", "aucun");
    const tot = (t, x, y, w, al) => s.addText(t, { x, y, w, h: 0.35, fontSize: 11, color: C.text2, align: al, margin: 0, isTextBox: true, objectName: `Total ${t}` });
    const yt = gy + 2 * ch + gap + 0.12;
    tot(`Total : ${frInt(el.solN + ex.solN)} (${frNum(el.solP + ex.solP)} %)`, gx, yt, cw, "center");
    tot(`Total : ${frInt(el.exclN + ex.exclN)} (${frNum(el.exclP + ex.exclP)} %)`, gx + cw + gap, yt, cw, "center");
    tot(`Total : ${frInt(el.solN + el.exclN)} (${frNum(el.solP + el.exclP)} %)`, 0.5, gy + ch / 2 + 0.3, 2.25, "right");
    tot(`Total : ${frInt(ex.solN + ex.exclN)} (${frNum(ex.solP + ex.exclP)} %)`, 0.5, gy + 1.5 * ch + gap + 0.38, 2.25, "right");
    s.addText("Chaque entreprise du MSCI World est dans une seule case.", { x: 0.5, y: 6.4, w: 7.7, h: 0.35, fontSize: 11, italic: true,
      color: C.text2, margin: 0, isTextBox: true, objectName: "Lecture croisement" });
    encadres(s, ["Deux univers, une intersection", "Une entreprise entre dans l'univers du fonds si elle passe les 6 filtres extra-financiers ET les 5 filtres financiers."],
                ["Ce que le financier retire", `${frInt(el.exclN)} entreprises durables mais fragiles (pertes, dette, volatilité) : ${frNum(el.exclP)} points d'indice seulement. La sélectivité vient de l'extra-financier.`],
                "Durable et solide, sinon rien.", "inter");
  }
  s.addNotes(
    "Message : l'univers du fonds est l'intersection des deux univers, comme dans le cours. Une entreprise doit être à la fois éligible Article 9 (6 filtres extra-financiers) et solide financièrement (5 filtres financiers).\n\n" +
    "Lecture du tableau croisé : en ligne, le verdict extra-financier ; en colonne, le verdict financier. La case foncée, en haut à gauche, est notre univers sélectionnable. Chaque entreprise du MSCI World est dans une seule case.\n\n" +
    "Les chiffres : 344 entreprises durables et solides (35,9 % de l'indice). 151 durables mais fragiles (4,6 % de l'indice seulement : surtout de petites capitalisations, peu rentables ou peu liquides). 481 solides mais non durables (46,0 %, dont Apple, Amazon, Meta, JPMorgan). 271 ni l'un ni l'autre.\n\n" +
    "Ce qu'il faut retenir : le filtre financier coûte peu en poids (4,6 points), il retire surtout des petites valeurs fragiles. L'essentiel de la sélectivité vient des filtres extra-financiers.\n\n" +
    "Transition : dans ces 344 entreprises, nous choisissons les lignes du fonds, réparties en deux poches."
  );

  // ---------- Slide 11 : classement des 344, carte de la symbiose ----------
  pres.addSection({ title: "Construction du portefeuille" });
  s = pres.addSlide({ masterName: "CONTENU", sectionTitle: "Construction du portefeuille" });
  s.addText("La carte de la symbiose", { placeholder: "title" });
  {
    const P = fs.readFileSync(path.join(__dirname, "..", "resultats", "classement_lichen.csv"), "utf8").trim().split(/\r?\n/).slice(1)
      .map((l) => { const c = l.split(","); return { name: c[1], secteur: c[2], sm: +c[4], sv: +c[5], sf: +c[6], w: +c[16] }; });
    const court = (n) => ({ "Schneider Electric SE": "Schneider Electric", "Dassault Systemes SE": "Dassault Systèmes",
      "Zurich Insurance Group AG": "Zurich Insurance", "Check Point Software Technolog": "Check Point Software",
      "Hannover Rueck SE": "Hannover Re", "Wolters Kluwer NV": "Wolters Kluwer" }[n] ||
      n.replace(/ (Inc|Corp|SE|SA|AG|PLC|plc|Ltd|NV|A\/S|ASA|Oyj|Co|Cos|Group)\b/g, "").trim());
    const somme = P.reduce((a, r) => a + r.w, 0);
    jauge(s, "Aucune exclusion : les 344 entreprises sont classées", somme, somme, P.length, "classement");
    s.addImage({ path: path.join(FIG, "G9_carte_symbiose_slide.png"), x: 0.5, y: 1.45, w: 6.6, h: 4.85,
      altText: "Nuage de points des 344 entreprises de l'intersection : score financier en abscisse, score vert en ordonnée, couleur selon le score moyen. Les podiums des trois classements sont nommés.",
      objectName: "Carte de la symbiose" });
    s.addText("Un point = une entreprise. Scores comparés au secteur, de 0 à 100. Score moyen = 50 % vert + 50 % financier.",
      { x: 0.5, y: 6.4, w: 6.6, h: 0.35, fontSize: 10.5, italic: true, color: C.text2, margin: 0, isTextBox: true, objectName: "Lecture carte" });
    const X3 = 7.35, W3 = 13.33 - 0.5 - X3, H3 = 1.67, G3 = 0.12;
    const boite = (k, fonce, titre, cle) => {
      const y = 1.5 + k * (H3 + G3);
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: X3, y, w: W3, h: H3, rectRadius: 0.1, fill: { color: fonce ? C.text1 : C.background2 },
        line: { type: "none" }, objectName: `Boîte ${titre}` });
      s.addText(titre, { x: X3 + 0.25, y: y + 0.08, w: W3 - 0.5, h: 0.32, fontSize: 13, bold: true, color: fonce ? C.accent2 : C.text1,
        margin: 0, valign: "middle", isTextBox: true, objectName: `Titre ${titre}` });
      const top = [...P].sort((a, b) => b[cle] - a[cle]).slice(0, 5);
      const runs = (f) => top.map((r, i) => ({ text: f(r, i), options: { breakLine: i < top.length - 1 } }));
      const opt = { y: y + 0.42, h: H3 - 0.5, fontSize: 10.5, valign: "top", margin: 0, paraSpaceAfter: 0.5, isTextBox: true };
      s.addText(runs((r, i) => `${i + 1}. ${court(r.name)}`), { ...opt, x: X3 + 0.25, w: 2.55, color: fonce ? C.background1 : C.text1, objectName: `Noms ${titre}` });
      s.addText(runs((r) => r.secteur), { ...opt, x: X3 + 2.85, w: 1.75, color: fonce ? C.accent3 : C.text2, objectName: `Secteurs ${titre}` });
      s.addText(runs((r) => frNum(r[cle], 0)), { ...opt, x: X3 + W3 - 0.95, w: 0.7, align: "right", bold: true,
        color: fonce ? C.accent2 : C.accent1, objectName: `Scores ${titre}` });
    };
    boite(0, true, "Meilleures en moyenne", "sm");
    boite(1, false, "Meilleures en vert", "sv");
    boite(2, false, "Meilleures en financier", "sf");
  }
  s.addNotes(
    "Message : les 344 entreprises durables et solides reçoivent trois notes. Nous n'excluons personne à cette étape : ces notes serviront à construire les deux poches du fonds et à les pondérer.\n\n" +
    "Les trois notes, toutes comparées au secteur (rang de 0 à 100, une banque est comparée aux banques) :\n- score vert : CA vert, température implicite, intensité carbone, alignement ODD environnemental ;\n- score financier : rentabilité, ratio de Sharpe 5 ans, rendement du cash-flow libre, faible volatilité ;\n- score moyen : 50 % vert et 50 % financier, la symbiose des deux.\n\n" +
    "Lecture de la carte : un point = une entreprise ; vers la droite, meilleure en financier ; vers le haut, meilleure en vert ; plus le point est foncé, meilleur est son score moyen. Les deux notes sont presque indépendantes (corrélation 0,07) : être vert ne dit rien de la qualité financière, d'où l'intérêt de deux poches.\n\n" +
    "Les podiums : en vert, AECOM, Dassault Systèmes, Jacobs (ingénierie de l'eau, logiciels de conception) ; en financier, Iberdrola, Public Storage, Holcim ; en moyenne, Iberdrola, Novartis, Zurich. Iberdrola, champion des renouvelables, est première en financier et en moyenne : c'est la symbiose, performance et climat ensemble.\n\n" +
    "Transition : la suite construit les deux poches, Photosynthèse (les meilleures en vert) et Noyau (les meilleures en financier), puis fixe le poids de chaque ligne en minimisant l'écart au MSCI World."
  );

  await pres.writeFile({ fileName: OUT });
  await applyTheme(OUT, THEME);
  console.log("écrit", OUT);
})();
