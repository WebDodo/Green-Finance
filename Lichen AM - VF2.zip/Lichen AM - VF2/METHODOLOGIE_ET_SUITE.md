# Lichen Symbiose Climat — méthodologie et consignes pour la suite

**Lichen Asset Management · fonds actions monde · SFDR Article 9 · « La performance et le climat, en symbiose. »**

Projet final de Finance durable (Université Paris-Dauphine, T. Béchu et J. Jardel, Kanopy AM).
Ce document résume **tout ce qui est fait (étapes 0 à 9)** et décrit **ce qu'il reste à faire (étape 10 : les deux poches, la pondération, les résultats)**.

> **Échéance** : envoi avant le **mardi 24/11/2026 à 23 h 59** à thierry.bechu@kanopy-am.com et jean.jardel@kanopy-am.com.
> **Livrables** : une présentation d'environ 10 slides, un Excel « portefeuille » (actifs et poids), un Excel « données complémentaires ».
> **Soutenance** : 26/11 ou 03/12/2026, 15 min + 5 min de questions.

---

## 1. Démarrer

### Arborescence

| Dossier / fichier | Contenu |
|---|---|
| `code_py/Lichen_AM_V16.ipynb` | **Notebook de référence**, à jour, exécuté de bout en bout (étapes 0 à 9). Les versions V5 à V15 sont des archives. |
| `code_py/extraire_prix_yahoo.py` | Script qui a téléchargé les cours Yahoo Finance (déjà fait, inutile de le relancer). |
| `data/all_data.csv` | Données du cours : MSCI World au 31/12/2024, 1 247 valeurs, 100 colonnes. |
| `data/externes/` | Données externes : Global Coal Exit List 2026 (urgewald), Global Coal Mine Tracker août 2026 (GEM), cours Yahoo quotidiens du 02/12/2019 au 20/11/2026 (`prix_yahoo_quotidiens.csv`, 1 247 titres + ETF de référence), taux de change EUR (`change_eur.csv`). |
| `resultats/` | Tous les tableaux produits par le notebook (CSV) et les figures (`figures/`). |
| `presentation/Lichen_AM_Presentation.pptx` | Les 11 slides faites. Générées par `presentation/build_deck.js` (pptxgenjs). |

### Lancer le notebook

Python 3 avec `pandas`, `numpy`, `scipy`, `matplotlib`, `openpyxl`. Ouvrir `Lichen_AM_V16.ipynb` à la racine du projet et tout exécuter (environ 1 minute). Toutes les variables utiles sont alors en mémoire, notamment :

- `df` : les 1 247 valeurs, avec toutes les colonnes construites (secteur et région en français, `poids_indice`, `ca_vert`, `ITR`, `intensite_s12`, `empreinte_s123`, colonnes `exclu_*`, `eligible_article9`, `univers_financier`, `selectionnable`) ;
- `S` : les **344 entreprises de l'intersection**, avec `score_vert`, `score_financier`, `score_moyen` et leurs rangs ;
- `FICHIER_PRIX`, `DATA`, `OUT`, `FIG`, `COL` (couleurs de la charte), `fr_pct` (format français).

> **Fichiers obsolètes dans `resultats/`** : `portefeuille_lichen_symbiose.csv`, `conformite.csv`, `poches_lichen.csv` et la figure `G8_portefeuille_poches.png` viennent d'un ancien essai. Ne pas les utiliser ; l'étape 10 les remplacera.

---

## 2. Ce qui est fait : la méthodologie (étapes 0 à 9)

### Le principe

Le chemin suit le cours *Approche Quantitative* (J. Jardel) : **univers extra-financier** (filtres d'exclusion) ∩ **univers financier** → **univers sélectionnable** → classement → pondération par optimisation sous contraintes.

Règles de mesure, appliquées partout :
- chaque filtre est d'abord **mesuré seul sur tout le MSCI World**, puis on indique ce qu'il retire **en plus** des filtres précédents ;
- « % de l'indice » = **en poids** (capitalisation) ; « entreprises » = **en nombre** ;
- **donnée manquante = exclusion** (prudence) ;
- les seuils **relatifs** (« les X % pires ») sont **comparés au secteur** quand les niveaux diffèrent beaucoup d'un secteur à l'autre (carbone, volatilité).

### Étape 1 — Le constat (slide 2)

Matrice de corrélation (Spearman) entre 15 métriques extra-financières MSCI : **corrélation moyenne 0,14**. **34 %** des entreprises notées AAA (68 sur 201) ont une trajectoire au-dessus de 2 °C. Le CA vert est corrélé à **−0,32** au faible carbone (« paradoxe vert » : les producteurs de solutions émettent). Conclusion : une seule note ne suffit pas, il faut combiner des filtres et raisonner par secteur.

### Étapes 2 à 6 — Les 6 filtres extra-financiers (slides 3 à 8)

| # | Filtre | Règle | Pourquoi | Exclues seul (nb · % indice) | En plus | Il reste |
|---|---|---|---|---|---|---|
| 1 | **Bonne gouvernance** | Note ESG MSCI ≥ BB (on exclut B, CCC, sans note) | SFDR art. 2.17 : bonne gouvernance obligatoire | 27 · 2,6 % | 27 | **1 220 · 97,4 %** |
| 2 | **Ne pas nuire (DNSH)** | Aucune controverse grave : score E, S ou G < 2/10 | SFDR art. 2.17 : pas de préjudice important | 189 · 33,6 % | 174 | **1 046 · 66,0 %** |
| 3 | **Accord de Paris** | Température implicite < 3,1 °C (on exclut les 20 % les plus chaudes, seuil global) | Trajectoire compatible avec Paris | 270 · 15,7 % | 213 | **833 · 55,8 %** |
| 4 | **Exclusions Paris-Aligned** | Armes controversées, tabac, charbon ≥ 1 % du CA (urgewald), mines de charbon (GEM), tout le secteur Énergie, distribution de gaz, électricité carbonée (intensité S1 ≥ 1 000 t/M$ sauf ≥ 50 % de CA vert) | Le mot « Climat » impose les exclusions PAB (ESMA 2025, règlement 2020/1818 art. 12) | 109 · 8,0 % | 33 | **800 · 54,4 %** |
| 5 | **Carbone par secteur** | Exclusion des 10 % les plus émetteurs de **chaque secteur**, en empreinte S1+2+3 **ou** en intensité S1+2+3 (union des deux listes ; seuil calculé sur tout le MSCI) | Figure 11 du cours ; comparer à ses pairs évite le paradoxe vert | 202 · 12,2 % | 94 | **706 · 50,4 %** |
| 6 | **Contribution** | Au moins une « porte » : CA vert ≥ 20 %, ou température ≤ 1,5 °C, ou un ODD environnemental aligné (score MSCI ≥ 2) | SFDR art. 2.17 : un investissement durable doit **contribuer** | 483 · 31,6 % | 211 | **495 · 40,5 %** |

**Résultat : 495 entreprises éligibles Article 9 (40,5 % de l'indice) ; 752 exclues (59,5 %).** Sélectivité ≥ 30 % (label ISR) respectée.

Détails à connaître pour les questions :
- filtre 3 : un seuil par secteur garderait des entreprises jusqu'à 6,1 °C, d'où le seuil global ;
- filtre 4 : nos données n'ont pas la part du CA pétrole et gaz, donc on exclut **tout le secteur Énergie** (plus strict que la règle) ; le charbon vient de sources externes (urgewald GCEL 2026, GEM Coal Mine Tracker) ;
- filtre 5 : 65 entreprises exclues sur l'empreinte, 27 sur l'intensité seulement, 2 pour donnée manquante (parmi les 94 nouvelles) ;
- filtre 6 : seules 82 entreprises du MSCI World ont ≥ 20 % de CA vert, d'où les deux autres portes.

### Étape 8 — Les filtres financiers et l'intersection (slides 9 et 10)

Univers financier construit **sur tout le MSCI World**, indépendamment des filtres extra-financiers :

| Filtre | Règle | Exclues seul | En plus | Il reste |
|---|---|---|---|---|
| Rentabilité | ROIC > 0 (ROE pour la finance) et marge nette > 0 | 112 | 112 | 1 135 · 95,9 % |
| Bilan | Dette / actif ≤ 60 % (70 % immobilier et services aux collectivités ; pas de règle pour la finance) | 52 | 51 | 1 084 · 92,1 % |
| Risque | Volatilité 5 ans hors des 10 % pires **du secteur**, et perte maximale 5 ans > −70 % | 171 | 119 | 965 · 83,6 % |
| Liquidité | Poids dans le MSCI World ≥ 0,01 % | 147 | 105 | 860 · 82,9 % |
| Historique de cours | Cours Yahoo sur ≥ 95 % des **semaines** 2020-2024 | 87 | 35 | **825 · 81,8 %** |

> **Point de méthode** : mesuré en *jours*, l'historique excluait 276 entreprises dont 154 japonaises **sans aucune donnée manquante** (la bourse de Tokyo a plus de jours fériés, comptés comme des trous dans le calendrier commun). Mesuré en semaines, le biais disparaît.

**Intersection (tableau croisé)** :

| | Solide financièrement | Exclue par le financier |
|---|---|---|
| **Éligible Article 9** | **344 · 35,9 % → univers sélectionnable** | 151 · 4,6 % |
| **Exclue extra-financier** | 481 · 46,0 % | 271 · 13,5 % |

Le financier ne coûte que 4,6 points d'indice : la sélectivité vient de l'extra-financier.

### Étape 9 — Le classement des 344 (slide 11)

Aucune exclusion à cette étape : chaque entreprise de l'intersection reçoit **trois notes**, comparées à son secteur (rang centile au sein de l'intersection, de 0 à 100) :

| Score | Composantes (moyenne des rangs) |
|---|---|
| **Score vert** | CA vert ; température implicite (inversée) ; intensité carbone S1+2 (inversée) ; alignement ODD environnementaux (6, 7, 11 à 15) |
| **Score financier** | Rentabilité (ROIC, ROE pour la finance) ; ratio de Sharpe 5 ans ; rendement du cash-flow libre ; volatilité 5 ans (inversée) |
| **Score moyen** | 50 % score vert + 50 % score financier (paramètre `POIDS_VERT` dans le notebook) |

Les deux notes sont presque indépendantes (corrélation **0,07**) : d'où l'intérêt de deux poches.

Podiums : **vert** AECOM, Dassault Systèmes, Jacobs ; **financier** Iberdrola, Public Storage, Holcim ; **moyenne** Iberdrola, Novartis, Zurich.

Fichier : **`resultats/classement_lichen.csv`** (344 lignes : nom, secteur, région, trois scores, trois rangs, CA vert, température, intensité, rentabilité, Sharpe, volatilité, poids dans l'indice en %). La colonne `ligne_all_data` est l'index de la ligne dans `all_data.csv` / `df`.

---

## 3. Ce qu'il reste à faire : l'étape 10

### 10.1 Construire les deux poches

L'idée du fonds : **deux poches, comme les deux partenaires d'un lichen**.
- **Photosynthèse** (l'algue) : **les meilleures en vert**, celles qui financent les solutions de la transition.
- **Noyau** (le champignon) : **les meilleures en financier**, qui portent la performance et l'équilibre du fonds.

Toutes les lignes sont déjà éligibles Article 9 et solides financièrement. Tu choisis le nombre de lignes et la taille de chaque poche. Ce que nous avons appris en testant :

- **Photosynthèse** : prendre les meilleures par `score_vert` **parmi celles qui ont au moins 10 % de CA vert** (65 candidates dans l'intersection). Sans ce seuil, des entreprises à 0 % de CA vert (Novartis, Novo Nordisk, Swisscom, Zurich) entrent dans la poche verte grâce à leur seule trajectoire : difficile à défendre pour une poche « Photosynthèse ». À 20 % de CA vert, il ne reste que 29 candidates concentrées dans 3 secteurs : trop étroit. Limiter à **5 lignes par secteur** évite la concentration.
- **Noyau** : prendre les meilleures par `score_financier` parmi les autres. Pour rester proche de l'indice, on peut répartir les lignes par secteur au prorata du poids du secteur dans le MSCI World (hors Énergie, exclu).
- **Ordres de grandeur testés** : 25 lignes Photosynthèse (≈ 40 % du fonds) + 42 lignes Noyau (≈ 60 %) : toutes les contraintes tiennent, sauf l'écart sectoriel qui sort à 5,4 points (limite ± 5) ; 20 + 45 lignes avec 30 / 70 : tout tient (écart sectoriel 5,0 points). Avec 40 %, il faudra donc un peu d'ajustement (plus de lignes, ou ± 6 points par secteur).

### 10.2 Pondérer : minimiser la tracking error (méthode du prof)

Forme du cours : poids initiaux égaux (1/N), somme des poids = 1, bornes par ligne, minimisation d'une fonction objectif. Notre objectif : la **tracking error ex ante face au MSCI World** :

$$\min_w \; (w - b)^\top \Sigma \,(w - b) \quad \text{s.c.} \quad \sum_i w_i = 1, \quad w_{\min} \le w_i \le w_{\max}$$

avec `b` les poids du MSCI World (`df['poids_indice']`, les 1 247 valeurs) et `w` les poids du fonds (0 hors portefeuille).

**Contraintes recommandées** (testées ensemble ; voir la remarque sur l'écart sectoriel en 10.1) :

| Contrainte | Valeur | Origine |
|---|---|---|
| Poids par ligne | entre 0,5 % et 5 % | OPCVM 5/10/40 : aucune ligne > 5 %, donc la règle des 40 % est respectée |
| Taille de la poche Photosynthèse | ton choix (30 % ou 40 %) | Architecture du fonds |
| Température implicite du fonds | ≤ 1,8 °C (MSCI World : 2,40 °C) | Objectif Accord de Paris |
| Intensité carbone S1+2 et empreinte S1+2+3 | ≤ 50 % du MSCI World | Paris-Aligned (−50 %) |
| Secteurs à fort impact climatique | ≥ exposition du MSCI World | Paris-Aligned (proxy : énergie, matériaux, industrie, services aux collectivités, immobilier, consommation) |
| Part de CA vert | ≥ 1,5 × MSCI World (≈ 13,9 % vs 9,2 %) | Objectif de contribution ; 2 × est infaisable |
| Écart par secteur | ± 5 points vs MSCI World | Équilibre du fonds |
| Écart par région | ± 10 points vs MSCI World (Moyen-Orient regroupé avec Asie-Pacifique, Amérique latine avec Amérique du Nord) | Équilibre du fonds |

Moyennes du fonds = somme des poids × valeur de la ligne ; moyennes de l'indice = pondérées par `poids_indice` sur les valeurs renseignées.

**Matrice de covariance Σ** : rendements **hebdomadaires en euros** 2020-2024 (période connue au 31/12/2024, pas de biais d'anticipation), estimés à partir de `prix_yahoo_quotidiens.csv` et `change_eur.csv` (les taux sont en unités de devise pour 1 euro : prix en euros = prix local / taux). Rétrécissement de 30 % vers une corrélation constante. Pour les rares titres sans cours, un modèle simple suffit (volatilité 5 ans d'`all_data`, corrélation 0,5 dans un même secteur, 0,3 entre secteurs). Code de référence en annexe.

**Astuce** : avec la seule tracking error, l'optimiseur met beaucoup de lignes au plancher. Ajouter un petit terme de rappel vers une cible de conviction (par exemple proportionnelle au score de la poche) donne des poids plus lisibles : `objectif = TE² + λ · Σ (w − cible)² / cible`, avec λ ≈ 0,3. Utiliser `scipy.optimize.minimize(method='SLSQP')`. Si l'optimiseur échoue (« Positive directional derivative »), c'est souvent qu'une contrainte est infaisable : la tester seule avec `scipy.optimize.linprog`.

### 10.3 Montrer les résultats

1. **Tableau de conformité** : chaque contrainte, sa valeur, respectée ou non (100 % des lignes Article 9, OPCVM 5/10/40, carbone, température, CA vert, secteurs, régions).
2. **Résultats extra-financiers, fonds vs MSCI World** (figures 13-14 du cours) : température, intensité et empreinte carbone, CA vert, note ESG moyenne, part de controverses, quelques PAI (émissions, exposition fossile = 0, diversité du conseil si dispo).
3. **Analyse sectorielle et régionale** : barres fonds vs MSCI World par secteur et par région, top 10 des lignes, poids de chaque poche. Montrer que le fonds reste **équilibré** (écarts ≤ 5 points par secteur).
4. **Performance passée** (avec les cours Yahoo, en euros) :
   - période **2020-2024** (dans l'échantillon) et **01/2025 → 11/2026** (hors échantillon, le plus parlant) ;
   - comparer au **MSCI World** (ETF `URTH` en USD converti, ou `IWDA.AS` en EUR) et aux ETF **Paris-Aligned** (`PABV.DE` depuis 09/2021, `PABW.DE` depuis 12/2023) ;
   - indicateurs : rendement annualisé, volatilité, ratio de Sharpe, tracking error ex post, perte maximale ; graphique base 100 ;
   - prudence à l'oral : rebalancement non modélisé, biais du survivant (univers fixé au 31/12/2024), frais non déduits ; « les performances passées ne préjugent pas des performances futures ».
5. **La carte finale** : reprendre la carte de la symbiose (figure `G9_carte_symbiose`, fonction `dessiner_symbiose` du notebook), **colorer les entreprises retenues selon leur poche** (vert Photosynthèse, vert foncé Noyau, gris les autres) et faire varier **la taille des points selon le poids** dans le fonds (par exemple `s = 20 + 4000 × poids`).

### 10.4 Slides et livrables

- **Slides à ajouter** (12 à environ 15) : les deux poches et la pondération ; les résultats extra-financiers ; l'analyse sectorielle ; la performance ; une synthèse avec la fiche du fonds et les **mentions AMF** (risque de perte en capital, performances passées, document promotionnel, SFDR Article 9, indice de référence MSCI World Climate Paris Aligned). Garder la charte : `build_deck.js` contient les fonctions `jauge`, `cartesBas`, `encadres` et le thème Lichen (vert forêt `16261D`, vert `4F7F52`, vert lichen `C2D46A`, Cambria / Calibri).
- **Excel 1 · Portefeuille** : ISIN, nom, secteur, région, poche, poids.
- **Excel 2 · Données complémentaires** : les CSV de `resultats/` (entonnoirs, croisement, classement, exclusions par filtre, correspondances charbon, conformité, résultats extra-financiers).
- 15 minutes pour environ 15 slides : si besoin, passer les slides des filtres 3 et 4 en annexe.

### 10.5 Points d'attention

- **Mowi** (saumon d'élevage) et **Boston Properties** (bureaux, 2,6 °C) ressortent souvent dans la poche verte : défendables par les données MSCI, mais un jury peut tiquer. À assumer ou à écarter.
- **Japon** : depuis la correction de l'historique de cours, des valeurs japonaises sont sélectionnables (Sony, Kubota, SoftBank, MS&AD…). Vérifier que le fonds n'est pas trop sous-pondéré sur le Japon.
- **Iberdrola** : 1re en financier et en moyenne alors que c'est un champion des renouvelables : bel exemple de « symbiose » pour l'oral.
- L'écart sectoriel de ± 5 points est la contrainte la plus serrée avec une grosse poche verte (secteurs industrie et services aux collectivités).

---

## Annexe — code de référence (testé avec le notebook V16)

À coller dans de nouvelles cellules après l'étape 9. `PF` = DataFrame des lignes retenues (index = index de `df`), avec une colonne `poche`.

```python
from scipy.optimize import minimize

vol = df['Volatility 5Y'].to_numpy(float)
sect = df['secteur'].to_numpy(object)

def covariance_modele():
    C = np.where(sect[:, None] == sect[None, :], 0.5, 0.3)
    np.fill_diagonal(C, 1.0)
    return C * np.outer(vol, vol)

def rendements_hebdo_eur(debut, fin):
    prix = pd.read_csv(FICHIER_PRIX, index_col=0, parse_dates=True).loc[debut:fin]
    change = pd.read_csv(DATA / 'externes' / 'change_eur.csv', index_col=0, parse_dates=True)
    hebdo = prix.resample('W-FRI').last()
    fx = change.resample('W-FRI').last().reindex(hebdo.index).ffill()
    devise = df.drop_duplicates('ticker_yahoo').set_index('ticker_yahoo')['currency'].str.upper()
    devise = devise.reindex(hebdo.columns).fillna('USD')
    devise.loc[[c for c in hebdo.columns if c.endswith(('.AS', '.DE'))]] = 'EUR'
    eur = hebdo.copy()
    for d in devise.unique():
        if d != 'EUR' and d in fx:
            cols = devise.index[devise == d]
            eur[cols] = hebdo[cols].div(fx[d], axis=0)      # unités de devise pour 1 euro -> prix en euros
    return eur.pct_change(fill_method=None).iloc[1:]

def covariance_cours():
    r = rendements_hebdo_eur('2019-12-01', '2024-12-31')
    r = r[[t for t in df['ticker_yahoo'] if t in r and r[t].notna().mean() > 0.8]]
    cov_s = r.cov() * 52
    sd = np.sqrt(np.diag(cov_s)); corr = cov_s.values / np.outer(sd, sd)
    rho = (np.nansum(corr) - len(sd)) / (len(sd) * (len(sd) - 1))
    cible = rho * np.outer(sd, sd); np.fill_diagonal(cible, sd ** 2)
    cov_r = 0.7 * cov_s.values + 0.3 * cible                  # rétrécissement 30 % vers la corrélation constante
    Sig = covariance_modele()
    pos_t = {t: i for i, t in enumerate(df['ticker_yahoo'])}
    ids = [pos_t[t] for t in cov_s.columns]
    Sig[np.ix_(ids, ids)] = cov_r
    return Sig

SIGMA = covariance_cours()
b = df['poids_indice'].to_numpy(float)
pos = np.array([df.index.get_loc(i) for i in PF.index]); n = len(pos)
est_verte = (PF['poche'] == 'Photosynthèse').to_numpy()
PART_VERTE = 0.40
region_c = df['region'].replace({'Moyen-Orient': 'Asie-Pacifique', 'Amérique latine': 'Amérique du Nord'}).to_numpy(object)
fort_impact = np.isin(sect, ['Énergie', 'Matériaux', 'Industrie', 'Services aux coll.', 'Immobilier', 'Conso. de base', 'Conso. disc.'])

def moyenne_indice(col):
    v = df[col].to_numpy(float); m = ~np.isnan(v)
    return float((v[m] * b[m]).sum() / b[m].sum())
def moyenne_fonds(col, x):
    return float(np.nansum(df[col].to_numpy(float)[pos] * x))
def tracking_error2(x):
    a = -b.copy(); a[pos] += x
    return float(a @ SIGMA @ a)

REF = {c: moyenne_indice(c) for c in ['ITR', 'intensite_s12', 'empreinte_s123', 'ca_vert']}
contraintes = [
    {'type': 'eq', 'fun': lambda x: x.sum() - 1},
    {'type': 'eq', 'fun': lambda x: x[est_verte].sum() - PART_VERTE},
    {'type': 'ineq', 'fun': lambda x: 1.8 - moyenne_fonds('ITR', x)},
    {'type': 'ineq', 'fun': lambda x: 0.5 * REF['intensite_s12'] - moyenne_fonds('intensite_s12', x)},
    {'type': 'ineq', 'fun': lambda x: 0.5 * REF['empreinte_s123'] - moyenne_fonds('empreinte_s123', x)},
    {'type': 'ineq', 'fun': lambda x: moyenne_fonds('ca_vert', x) - 1.5 * REF['ca_vert']},
    {'type': 'ineq', 'fun': lambda x: x[fort_impact[pos]].sum() - b[fort_impact].sum()},
]
for s_ in np.unique(sect):
    m, bw = sect[pos] == s_, b[sect == s_].sum()
    contraintes += [{'type': 'ineq', 'fun': lambda x, m=m, bw=bw: 0.05 - (x[m].sum() - bw)},
                    {'type': 'ineq', 'fun': lambda x, m=m, bw=bw: 0.05 + (x[m].sum() - bw)}]
for r_ in np.unique(region_c):
    m, bw = region_c[pos] == r_, b[region_c == r_].sum()
    contraintes += [{'type': 'ineq', 'fun': lambda x, m=m, bw=bw: 0.10 - (x[m].sum() - bw)},
                    {'type': 'ineq', 'fun': lambda x, m=m, bw=bw: 0.10 + (x[m].sum() - bw)}]

# Cible de conviction (facultative) : Photosynthèse au prorata du score vert, Noyau au prorata de racine(poids indice) x score financier
cible = np.where(est_verte, PF['score_vert'].to_numpy(), np.sqrt(b[pos]) * PF['score_financier'].to_numpy())
cible[est_verte] *= PART_VERTE / cible[est_verte].sum()
cible[~est_verte] *= (1 - PART_VERTE) / cible[~est_verte].sum()
cible = np.clip(cible, 0.005, 0.05)
LAMBDA = 0.3
objectif = lambda x: tracking_error2(x) + LAMBDA * float(np.sum((x - cible) ** 2 / cible))

res = minimize(objectif, np.full(n, 1 / n), method='SLSQP', bounds=[(0.005, 0.05)] * n,
               constraints=contraintes, options={'maxiter': 1000, 'ftol': 1e-12})
PF['poids'] = res.x
print(res.message, f"· tracking error ex ante = {np.sqrt(tracking_error2(res.x)):.2%}")
```

Lors de nos essais (25 lignes Photosynthèse à 40 % et 42 lignes Noyau), on obtenait une tracking error ex ante d'environ **4,8 %**, une température de **1,68 °C**, un carbone à **−50 %** et un CA vert de **13,9 %** (contre 9,2 % pour le MSCI World), mais un écart sectoriel maximal de 5,4 points : SLSQP peut s'arrêter avec une contrainte légèrement violée, toujours la vérifier dans le tableau de conformité.
